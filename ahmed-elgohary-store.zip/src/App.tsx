import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { ProductDetailsModal } from './components/ProductDetailsModal';
import { ProductsFilter, SortOption } from './components/ProductsFilter';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { AdminProductModal } from './components/AdminProductModal';
import { ReviewsSection } from './components/ReviewsSection';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Toast } from './components/Toast';

import {
  Product,
  CartItem,
  ProductCategory,
  ProductColor,
  Order,
  CustomerReview,
  ToastMessage
} from './types';

import {
  INITIAL_PRODUCTS,
  INITIAL_REVIEWS,
  FREE_SHIPPING_THRESHOLD
} from './data/products';

import { Flame, Sparkles, Tag, ArrowLeft, SearchX, ShoppingBag } from 'lucide-react';

export default function App() {
  // Products state (stored in localStorage for persistence)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('ahmed_elgohary_products');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_PRODUCTS;
  });

  // Cart state
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ahmed_elgohary_cart');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Wishlist state
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('ahmed_elgohary_wishlist');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ['ae-01', 'ae-02'];
  });

  // Reviews state
  const [reviews, setReviews] = useState<CustomerReview[]>(() => {
    try {
      const saved = localStorage.getItem('ahmed_elgohary_reviews');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_REVIEWS;
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('ahmed_elgohary_orders');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [];
  });

  // Filter & Search states
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [selectedSize, setSelectedSize] = useState<string>('الكل');
  const [selectedColor, setSelectedColor] = useState<string>('الكل');
  const [priceRange, setPriceRange] = useState<'all' | 'under1000' | '1000-1500' | 'above1500'>('all');
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeSection, setActiveSection] = useState<string>('hero');

  // Modals & Drawers
  const [selectedProductForModal, setSelectedProductForModal] = useState<Product | null>(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [wishlistDrawerOpen, setWishlistDrawerOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);

  // Promo Code
  const [appliedPromo, setAppliedPromo] = useState<string | null>('GOHARY10');
  const [toast, setToast] = useState<ToastMessage | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('ahmed_elgohary_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('ahmed_elgohary_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('ahmed_elgohary_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('ahmed_elgohary_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('ahmed_elgohary_orders', JSON.stringify(orders));
  }, [orders]);

  // Wishlist toggle
  const handleToggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      const next = exists ? prev.filter((id) => id !== productId) : [...prev, productId];
      const prod = products.find((p) => p.id === productId);
      if (!exists && prod) {
        setToast({
          id: `toast-${Date.now()}`,
          title: 'تمت الإضافة للمفضلة',
          message: `تم حفظ "${prod.name}" في قائمتك المفضلة.`
        });
      }
      return next;
    });
  };

  // Add to cart handler
  const handleAddToCart = (
    product: Product,
    selectedSize: string,
    selectedColor: ProductColor,
    quantity: number = 1
  ) => {
    setCart((prev) => {
      const cartItemId = `${product.id}-${selectedSize}-${selectedColor.name}`;
      const existingIndex = prev.findIndex((item) => item.cartItemId === cartItemId);

      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity
        };
        return next;
      } else {
        return [
          ...prev,
          {
            cartItemId,
            product,
            selectedSize,
            selectedColor,
            quantity
          }
        ];
      }
    });

    setToast({
      id: `toast-${Date.now()}`,
      title: 'تمت الإضافة إلى السلة بنجاح',
      message: `تم إضافة "${product.name}" (مقاس: ${selectedSize}) إلى حقيبة التسوق.`
    });
  };

  // Update Cart Quantity
  const handleUpdateCartQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveCartItem(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.cartItemId === cartItemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  // Remove Cart Item
  const handleRemoveCartItem = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
  };

  // Promo code calculation
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = appliedPromo === 'GOHARY10' ? Math.round(subtotal * 0.1) : 0;

  const handleApplyPromoCode = (code: string) => {
    const cleaned = code.trim().toUpperCase();
    if (cleaned === 'GOHARY10' || cleaned === 'ELGOHARY' || cleaned === 'SALE10') {
      setAppliedPromo(cleaned);
      return { success: true, message: 'تم تطبيق كود الخصم 10% بنجاح!' };
    }
    return { success: false, message: 'كود الخصم غير صالح أو منتهي الصلاحية' };
  };

  // Admin handlers
  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
    setToast({
      id: `toast-${Date.now()}`,
      title: 'تم نشر المنتج بنجاح',
      message: `أصبح المنتج "${newProd.name}" متاحاً الآن في المتجر.`
    });
  };

  const handleUpdateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    setToast({
      id: `toast-${Date.now()}`,
      title: 'تم حفظ التعديلات',
      message: `تم تحديث بيانات المنتج "${updated.name}" بنجاح.`
    });
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    setToast({
      id: `toast-${Date.now()}`,
      title: 'تم حذف المنتج',
      message: 'تمت إزالة المنتج من الكتالوج بنجاح.'
    });
  };

  // Filtering & Sorting logic
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category filter
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'men' && p.gender !== 'men' && p.gender !== 'unisex') return false;
        if (selectedCategory === 'women' && p.gender !== 'women' && p.gender !== 'unisex') return false;
        if (selectedCategory === 'offers' && !p.isOffer && !p.discountPercentage) return false;
        if (['hoodies', 'jackets', 'tshirts', 'pants', 'sets'].includes(selectedCategory)) {
          if (p.category !== selectedCategory) return false;
        }
      }

      // Size filter
      if (selectedSize !== 'الكل' && !p.sizes.includes(selectedSize)) {
        return false;
      }

      // Color filter
      if (selectedColor !== 'الكل' && !p.colors.some((c) => c.name.includes(selectedColor))) {
        return false;
      }

      // Price Range filter
      if (priceRange === 'under1000' && p.price >= 1000) return false;
      if (priceRange === '1000-1500' && (p.price < 1000 || p.price > 1500)) return false;
      if (priceRange === 'above1500' && p.price <= 1500) return false;

      // Search Query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = p.name.toLowerCase().includes(q);
        const matchEn = p.nameEn.toLowerCase().includes(q);
        const matchDesc = p.description.toLowerCase().includes(q);
        const matchCat = p.category.toLowerCase().includes(q);
        if (!matchName && !matchEn && !matchDesc && !matchCat) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'bestsellers') return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
      if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
      return 0; // featured default
    });
  }, [products, selectedCategory, selectedSize, selectedColor, priceRange, sortBy, searchQuery]);

  // Best Sellers (Curated top items)
  const bestSellers = useMemo(() => {
    return products.filter((p) => p.isBestSeller);
  }, [products]);

  // Special Offers (Items with discount)
  const offerProducts = useMemo(() => {
    return products.filter((p) => p.discountPercentage && p.discountPercentage > 0);
  }, [products]);

  // Navigate to sections smoothly
  const handleNavigateSection = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSelectedSize('الكل');
    setSelectedColor('الكل');
    setPriceRange('all');
    setSortBy('featured');
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-[#0c0c0e] text-neutral-100 flex flex-col font-['Cairo',sans-serif] selection:bg-amber-500/25 selection:text-amber-300">
      {/* Navbar with Top Bar Contract */}
      <Navbar
        cartCount={cart.reduce((s, i) => s + i.quantity, 0)}
        wishlistCount={wishlist.length}
        onOpenCart={() => setCartDrawerOpen(true)}
        onOpenWishlist={() => setWishlistDrawerOpen(true)}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onSearchChange={setSearchQuery}
        searchQuery={searchQuery}
        selectedCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          handleNavigateSection('products');
        }}
        activeSection={activeSection}
        onNavigateSection={handleNavigateSection}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <div id="hero">
          <Hero
            onShopClick={() => {
              setSelectedCategory('all');
              handleNavigateSection('products');
            }}
            onOffersClick={() => {
              setSelectedCategory('offers');
              handleNavigateSection('products');
            }}
          />
        </div>

        {/* Section 1: Best Sellers (المنتجات الأكثر مبيعاً) */}
        <section id="bestsellers" className="py-16 sm:py-20 bg-[#0e0e12] border-b border-neutral-800 text-right">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-3">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                  <Flame size={15} />
                  <span>القطع الأكثر طلباً هذا الموسم</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                  المنتجات الأكثر مبيعاً
                </h2>
              </div>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSortBy('bestsellers');
                  handleNavigateSection('products');
                }}
                className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 self-start sm:self-auto"
              >
                <span>مشاهدة الكل</span>
                <ArrowLeft size={14} />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {bestSellers.slice(0, 4).map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onOpenDetails={(p) => setSelectedProductForModal(p)}
                  onQuickAdd={(p, s, c) => handleAddToCart(p, s, c, 1)}
                  isWishlisted={wishlist.includes(product.id)}
                  onToggleWishlist={handleToggleWishlist}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Section 2: Main Catalog & Filterable Products (قسم المنتجات وأحدث المنتجات) */}
        <section id="products" className="py-16 sm:py-20 bg-[#0c0c0e] text-right">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-xl mx-auto mb-10">
              <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                كولكشن متكامل لجميع الأذواق
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-white font-display">
                كتالوج ملابس Ahmed Elgohary
              </h2>
              <p className="text-xs sm:text-sm text-neutral-400 mt-2">
                اختر الفئة أو المقاس أو اللون وتصفح مجموعتنا الفريدة المصنوعة بأعلى جودة.
              </p>
            </div>

            {/* Filter Controls Bar */}
            <ProductsFilter
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              selectedSize={selectedSize}
              onSelectSize={setSelectedSize}
              selectedColor={selectedColor}
              onSelectColor={setSelectedColor}
              priceRange={priceRange}
              onPriceRangeChange={setPriceRange}
              sortBy={sortBy}
              onSortByChange={setSortBy}
              totalProductsCount={products.length}
              filteredProductsCount={filteredProducts.length}
              onResetFilters={handleResetFilters}
            />

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onOpenDetails={(p) => setSelectedProductForModal(p)}
                    onQuickAdd={(p, s, c) => handleAddToCart(p, s, c, 1)}
                    isWishlisted={wishlist.includes(product.id)}
                    onToggleWishlist={handleToggleWishlist}
                  />
                ))}
              </div>
            ) : (
              /* Empty Search / Filter State (No items found) */
              <div className="py-20 text-center bg-[#111114] border border-neutral-800 rounded-2xl p-8 max-w-lg mx-auto">
                <div className="w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mx-auto mb-4 text-neutral-500">
                  <SearchX size={32} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">لا توجد منتجات مطابقة للبحث</h3>
                <p className="text-xs text-neutral-400 mb-6">
                  لم نتمكن من العثور على قطع تطابق الفلاتر المحددة. جرب تغيير المقاس أو اللون أو مسح كلمة البحث.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-6 py-2.5 bg-amber-400 text-black font-bold text-xs rounded-lg hover:bg-amber-300 transition-colors"
                >
                  عرض جميع المنتجات
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Section 3: Promotional Deals Banner & Grid (قسم العروض والخصومات) */}
        <section id="offers" className="py-16 sm:py-20 bg-gradient-to-b from-[#111115] to-[#0c0c0e] border-t border-b border-neutral-800 text-right">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-neutral-900 via-neutral-850 to-neutral-900 border border-amber-500/30 rounded-2xl p-6 sm:p-10 mb-10 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

              <div className="relative z-10 space-y-2 max-w-lg">
                <span className="text-xs bg-amber-500 text-black font-black px-2.5 py-1 rounded inline-block">
                  عروض محدودة
                </span>
                <h3 className="text-2xl sm:text-3xl font-black text-white font-display">
                  وفر حتى 25% مع كود الخصم الحصري
                </h3>
                <p className="text-xs sm:text-sm text-neutral-300">
                  استخدم كود <strong className="text-amber-300 font-mono tracking-widest text-sm bg-neutral-950 px-2 py-0.5 rounded border border-amber-500/30">GOHARY10</strong> في السلة واحصل على خصم 10% فوري إضافي على كافة الطلبات!
                </p>
              </div>

              <div className="relative z-10 shrink-0">
                <button
                  onClick={() => {
                    setSelectedCategory('offers');
                    handleNavigateSection('products');
                  }}
                  className="px-6 py-3.5 bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs sm:text-sm rounded-lg shadow-xl shadow-amber-500/20 transition-all cursor-pointer"
                >
                  تسوق عروض التخفيضات الآن
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {offerProducts.slice(0, 4).map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onOpenDetails={(p) => setSelectedProductForModal(p)}
                  onQuickAdd={(p, s, c) => handleAddToCart(p, s, c, 1)}
                  isWishlisted={wishlist.includes(product.id)}
                  onToggleWishlist={handleToggleWishlist}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Section 4: About & Brand Philosophy (من نحن) */}
        <AboutSection />

        {/* Section 5: Customer Reviews (آراء العملاء) */}
        <ReviewsSection
          reviews={reviews}
          onAddReview={(rev) => {
            setReviews((prev) => [rev, ...prev]);
            setToast({
              id: `toast-${Date.now()}`,
              title: 'شكراً لتقييمك!',
              message: 'تم تسجيل رأيك ومشاركته في صفحة التقييمات.'
            });
          }}
        />

        {/* Section 6: Contact Section (تواصل معنا) */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          handleNavigateSection('products');
        }}
        onNavigateSection={handleNavigateSection}
      />

      {/* Product Details Modal (PDP View) */}
      <ProductDetailsModal
        product={selectedProductForModal}
        onClose={() => setSelectedProductForModal(null)}
        onAddToCart={(p, s, c, q) => handleAddToCart(p, s, c, q)}
        isWishlisted={selectedProductForModal ? wishlist.includes(selectedProductForModal.id) : false}
        onToggleWishlist={handleToggleWishlist}
        relatedProducts={products.filter((p) => p.id !== selectedProductForModal?.id).slice(0, 3)}
        onSelectRelatedProduct={(p) => setSelectedProductForModal(p)}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={() => {
          setCartDrawerOpen(false);
          setCheckoutModalOpen(true);
        }}
        discountAmount={discountAmount}
        onApplyPromoCode={handleApplyPromoCode}
        appliedPromo={appliedPromo}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        items={cart}
        discountAmount={discountAmount}
        onCompleteOrder={(ord) => {
          setOrders((prev) => [ord, ...prev]);
          setToast({
            id: `toast-${Date.now()}`,
            title: 'تم تأكيد طلبك بنجاح!',
            message: `رقم طلبك هو ${ord.id}. شكراً لثقتك بـ Ahmed Elgohary.`
          });
        }}
        onClearCart={() => setCart([])}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={wishlistDrawerOpen}
        onClose={() => setWishlistDrawerOpen(false)}
        wishlistIds={wishlist}
        allProducts={products}
        onRemoveFromWishlist={handleToggleWishlist}
        onOpenProductDetails={(p) => {
          setWishlistDrawerOpen(false);
          setSelectedProductForModal(p);
        }}
      />

      {/* Admin / Product Management Modal */}
      <AdminProductModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        products={products}
        onAddProduct={handleAddProduct}
        onUpdateProduct={handleUpdateProduct}
        onDeleteProduct={handleDeleteProduct}
      />

      {/* Floating WhatsApp Quick Contact Button */}
      <FloatingWhatsApp />

      {/* Toast Notification */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />
    </div>
  );
}
