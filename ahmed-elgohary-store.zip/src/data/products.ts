import { Product, CustomerReview } from '../types';

import heroImg from '../assets/images/hero_fashion_banner_1791141481926.jpg';
import hoodieImg from '../assets/images/product_hoodie_luxury_1791141429954.jpg';
import bomberImg from '../assets/images/product_jacket_bomber_1791141446682.jpg';
import setImg from '../assets/images/product_streetwear_set_1791141457320.jpg';
import modelImg from '../assets/images/category_collection_model_1791141469020.jpg';

export { heroImg, hoodieImg, bomberImg, setImg, modelImg };

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'ae-01',
    name: 'هودي أوفرسايز فخم أسود كربوني',
    nameEn: 'Oversized Signature Black Hoodie',
    price: 1150,
    originalPrice: 1450,
    discountPercentage: 21,
    category: 'hoodies',
    gender: 'unisex',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'أسود فحمي', hex: '#141416' },
      { name: 'رمادي غامق', hex: '#373a40' },
      { name: 'بيج حجري', hex: '#d6c8b2' }
    ],
    images: [
      hoodieImg,
      modelImg
    ],
    description: 'هودي فاخر مصمم بقصة أوفرسايز مريحة مصنوع من أثقل خامات القطن المصري المعالج (420 GSM) مع بطانة داخلية فائقة النعومة وتطريز معدني هادئ لشعار Ahmed Elgohary على الكم.',
    fabric: 'قطن مصري 100% ميلتون تقيل 420 جرام معالج ضد الانكماش',
    fit: 'أوفرسايز واسع وعصري (Drop-Shoulder)',
    care: 'غسيل آلي بماء بارد ومقلوب، تجفيف على درجة حرارة منخفضة، تجنب الكي المباشر على التطريز',
    isBestSeller: true,
    isNew: true,
    isOffer: true,
    rating: 4.9,
    reviewsCount: 48,
    stockCount: 18
  },
  {
    id: 'ae-02',
    name: 'جاكيت بومبر تيلورد فاخر',
    nameEn: 'Luxury Tailored Bomber Jacket',
    price: 1850,
    originalPrice: 2200,
    discountPercentage: 16,
    category: 'jackets',
    gender: 'men',
    sizes: ['M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'إسبريسو غامق', hex: '#231e1b' },
      { name: 'أسود مطفي', hex: '#0e0e10' },
      { name: 'زيتي عسكري', hex: '#2e382d' }
    ],
    images: [
      bomberImg,
      heroImg
    ],
    description: 'قطعة أنيقة تعكس أرقى درجات الذوق الرفيع. خامة خارجية مقاومة للرياح مع سحّابات معدنية يابانية متينة وتفاصيل خياطة دقيقة تناسب الإطلالات الكاجوال والرسمية الراقية.',
    fabric: 'مزيج بوليستر مقاوم للماء مع قطن معالج وبطانة ستان حريرية',
    fit: 'قصة معتدلة مريحة ومحددة الكتفين (Modern Tailored Fit)',
    care: 'تنظيف جاف موصى به، أو غسيل يدوي بماء بارد',
    isBestSeller: true,
    isNew: true,
    isOffer: true,
    rating: 5.0,
    reviewsCount: 34,
    stockCount: 12
  },
  {
    id: 'ae-03',
    name: 'طقم بليزر وبنطلون ستريت وير كلاسيك',
    nameEn: 'Modern Tailored Minimal Blazer Set',
    price: 2450,
    originalPrice: 2900,
    discountPercentage: 15,
    category: 'sets',
    gender: 'women',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'كحلي داكن', hex: '#161b26' },
      { name: 'أسود ملكي', hex: '#111112' },
      { name: 'عاجي ناعم', hex: '#e8e5dc' }
    ],
    images: [
      setImg,
      modelImg
    ],
    description: 'طقم متناسق يتكون من بليزر بقصة متحررة وبنطلون مستقيم واسع. يجمع بين الجرأة الشبابية والرقي الأرستقراطي ليمنحك إطلالة فريدة في المناسبات والخروجات الراقية.',
    fabric: 'صوف بارد مخلوط مع ألياف قطنية عالية المرونة للمحافظة على القوام',
    fit: 'Relaxed Tailored مع أكتاف مبطنة برقة وبنطلون بخصر عالي',
    care: 'تنظيف جاف فقط للحفاظ على البنية الدقيقة للكتفين والياقة',
    isBestSeller: false,
    isNew: true,
    isOffer: true,
    rating: 4.8,
    reviewsCount: 22,
    stockCount: 9
  },
  {
    id: 'ae-04',
    name: 'سويت شيرت كولكشن الشتاء راوند',
    nameEn: 'Essential Heavyweight Crewneck',
    price: 950,
    originalPrice: 1200,
    discountPercentage: 20,
    category: 'hoodies',
    gender: 'unisex',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'أوف وايت', hex: '#f0ede6' },
      { name: 'رمادي ميلانج', hex: '#5c6068' },
      { name: 'أسود نقي', hex: '#121214' }
    ],
    images: [
      modelImg,
      hoodieImg
    ],
    description: 'سويت شيرت بتصميم مينيمال بدون قلنسوة، مثالي لطبقات الملابس الشتوية. خامة متماسكة لا تتكتل حتى بعد عشرات الغسلات مع تطريز خفي باسم البراند.',
    fabric: 'قطن تمشيط مزدوج 380 جرام مع أطراف مضلعة محكمة',
    fit: 'قصة ستاندرد بوكسي أنيقة',
    care: 'غسيل آلي على 30 درجة مئوية',
    isBestSeller: true,
    isNew: false,
    isOffer: true,
    rating: 4.7,
    reviewsCount: 56,
    stockCount: 25
  },
  {
    id: 'ae-05',
    name: 'تيشيرت بريميوم هيفي وايت بوكسي',
    nameEn: 'Heavy Cotton Boxy T-Shirt',
    price: 590,
    originalPrice: 750,
    discountPercentage: 21,
    category: 'tshirts',
    gender: 'unisex',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'أسود فحمي', hex: '#0f0f11' },
      { name: 'أبيض ناصع', hex: '#fdfdfd' },
      { name: 'زيتوني هادئ', hex: '#3b4339' },
      { name: 'رملي صحراوي', hex: '#c9bca9' }
    ],
    images: [
      heroImg,
      modelImg
    ],
    description: 'التيشيرت الأساسي الذي لا غنى عنه في خزانة أي شاب أنيق. خامة 280 جرام ثقيلة تحافظ على شكلها طوال اليوم، وياقة دائرية سميكة لا تترهل.',
    fabric: 'قطن مصري 100% قطفة أولى فاخرة',
    fit: 'Boxy Fit عصري مع أكمام أطول نسبياً',
    care: 'غسيل آلي بارد، لا تستخدم المبيضات',
    isBestSeller: true,
    isNew: false,
    isOffer: false,
    rating: 4.9,
    reviewsCount: 78,
    stockCount: 40
  },
  {
    id: 'ae-06',
    name: 'بنطلون كارغو ستريت بتفاصيل معدنية',
    nameEn: 'Utility Cargo Streetwear Trousers',
    price: 1250,
    originalPrice: 1550,
    discountPercentage: 19,
    category: 'pants',
    gender: 'men',
    sizes: ['30', '32', '34', '36', '38'],
    colors: [
      { name: 'أسود قاتم', hex: '#111113' },
      { name: 'رمادي خرساني', hex: '#3a3d42' },
      { name: 'كاكي بري', hex: '#4d4637' }
    ],
    images: [
      bomberImg,
      heroImg
    ],
    description: 'بنطلون كارجو هندسي مزود بجيوب ثلاثية الأبعاد وأحزمة شد في الكاحل تمكنك من تعديل القصة من بنطلون مستقيم إلى جوجر رياضي حسب رغبتك.',
    fabric: 'ريب ستوب قطني مقوى عالي التحمل',
    fit: 'قابل للتحويل بين Straight و Tapered',
    care: 'غسيل آلي عادي بدرجة حرارة معتدلة',
    isBestSeller: false,
    isNew: true,
    isOffer: true,
    rating: 4.8,
    reviewsCount: 29,
    stockCount: 15
  },
  {
    id: 'ae-07',
    name: 'جاكيت جينز داكن مغسول عتيق',
    nameEn: 'Washed Vintage Denim Trucker Jacket',
    price: 1650,
    originalPrice: 1950,
    discountPercentage: 15,
    category: 'jackets',
    gender: 'unisex',
    sizes: ['M', 'L', 'XL'],
    colors: [
      { name: 'أزرق دينيم عتيق', hex: '#1d2738' },
      { name: 'أسود معتق', hex: '#1c1c1f' }
    ],
    images: [
      modelImg,
      setImg
    ],
    description: 'جاكيت دينيم عالي الجودة بتأثير غسيل حمضي يدوي يمنحه لمسة فريدة لكل قطعة على حدة، مع أزرار معدنية محفور عليها شارة Ahmed Elgohary الأصلية.',
    fabric: 'دينيم ياباني أصيل 14 أونصة قطن 100%',
    fit: 'أوفرسايز مريح مع أطراف قابلة للتعديل',
    care: 'يغسل بمفرده لأول مرة للحفاظ على تدرجات الصبغة',
    isBestSeller: false,
    isNew: true,
    isOffer: false,
    rating: 4.9,
    reviewsCount: 19,
    stockCount: 8
  },
  {
    id: 'ae-08',
    name: 'كارديجان أوفرسايز تريكو ثقيل',
    nameEn: 'Heavy Knit Oversized Cardigan',
    price: 1350,
    originalPrice: 1600,
    discountPercentage: 15,
    category: 'hoodies',
    gender: 'women',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'بيج كراميل', hex: '#8a6b47' },
      { name: 'رمادي فحمي', hex: '#25262a' },
      { name: 'أخضر غابات داكن', hex: '#1d2920' }
    ],
    images: [
      setImg,
      hoodieImg
    ],
    description: 'كارديجان ناعم ومريح محبوك بخيوط صوفية ثقيلة تمنحك الدفء دون التنازل عن اللوك المودرن الفخم. أزرار صدفية بنية وقصة مريحة تليق بكل الإطلالات.',
    fabric: 'مزيج صوف ميرينو وألياف أكريليك فاخرة ناعمة الملمس',
    fit: 'فضفاض واسع بنعومة',
    care: 'غسيل يدوي أو تنظيف صوف خاص دون عصر',
    isBestSeller: true,
    isNew: true,
    isOffer: true,
    rating: 5.0,
    reviewsCount: 31,
    stockCount: 11
  }
];

export const INITIAL_REVIEWS: CustomerReview[] = [
  {
    id: 'rev-01',
    author: 'أحمد مراد',
    city: 'التجمع الخامس، القاهرة',
    rating: 5,
    comment: 'الخامة بجد فوق الممتازة! الهودي تقيل جداً ووزنه محترم والتقفيل والتطريز يضاهي براندات عالمية بأسعار أضعاف. التوصيل وصلني تاني يوم.',
    productPurchased: 'هودي أوفرسايز فخم أسود كربوني',
    date: 'منذ يومين',
    verified: true
  },
  {
    id: 'rev-02',
    author: 'كريم عبد الرحمن',
    city: 'سموحة، الإسكندرية',
    rating: 5,
    comment: 'البومبر جاكيت فخم بشكل غير طبيعي. كل اللي شافه سألني جبته منين. مقاسه مظبوط بالظبط على اللي اخترته في جدول المقاسات.',
    productPurchased: 'جاكيت بومبر تيلورد فاخر',
    date: 'منذ 5 أيام',
    verified: true
  },
  {
    id: 'rev-03',
    author: 'سارة الجوهري',
    city: 'الشيخ زايد، الجيزة',
    rating: 5,
    comment: 'طقم البليزر طلع خيال! القماش طري ومابيلمش وبرة خالص، والستايل شبابي وشيك جداً. خدمة العملاء على الواتساب متعاونين جداً.',
    productPurchased: 'طقم بليزر وبنطلون ستريت وير كلاسيك',
    date: 'منذ أسبوع',
    verified: true
  },
  {
    id: 'rev-04',
    author: 'محمود الصاوي',
    city: 'المنصورة، الدقهلية',
    rating: 5,
    comment: 'التيشيرت الهيفي وزنه تحفة على الجسم والياقة محكمة جداً بعد الغسيل. طلبت ألوان تانية فوراً. شكراً للأستاذ أحمد الجوهري على البراند المشرف.',
    productPurchased: 'تيشيرت بريميوم هيفي وايت بوكسي',
    date: 'منذ 10 أيام',
    verified: true
  }
];

export const EGYPT_GOVERNORATES = [
  { name: 'القاهرة', shippingFee: 45, deliveryDays: '1-2 أيام' },
  { name: 'الجيزة', shippingFee: 45, deliveryDays: '1-2 أيام' },
  { name: 'الإسكندرية', shippingFee: 55, deliveryDays: '2-3 أيام' },
  { name: 'القليوبية', shippingFee: 50, deliveryDays: '2-3 أيام' },
  { name: 'الدقهلية (المنصورة)', shippingFee: 55, deliveryDays: '2-3 أيام' },
  { name: 'الغربية (طنطا)', shippingFee: 55, deliveryDays: '2-3 أيام' },
  { name: 'الشرقية (الزقازيق)', shippingFee: 55, deliveryDays: '2-3 أيام' },
  { name: 'المنوفية', shippingFee: 55, deliveryDays: '2-3 أيام' },
  { name: 'البحيرة', shippingFee: 60, deliveryDays: '2-4 أيام' },
  { name: 'بورسعيد', shippingFee: 60, deliveryDays: '2-3 أيام' },
  { name: 'الإسماعيلية', shippingFee: 60, deliveryDays: '2-3 أيام' },
  { name: 'السويس', shippingFee: 60, deliveryDays: '2-3 أيام' },
  { name: 'دمياط', shippingFee: 60, deliveryDays: '2-3 أيام' },
  { name: 'كفر الشيخ', shippingFee: 60, deliveryDays: '2-4 أيام' },
  { name: 'بني سويف', shippingFee: 65, deliveryDays: '3-4 أيام' },
  { name: 'الفيوم', shippingFee: 65, deliveryDays: '3-4 أيام' },
  { name: 'المنيا', shippingFee: 70, deliveryDays: '3-5 أيام' },
  { name: 'أسيوط', shippingFee: 70, deliveryDays: '3-5 أيام' },
  { name: 'سوهاج', shippingFee: 75, deliveryDays: '3-5 أيام' },
  { name: 'قنا', shippingFee: 75, deliveryDays: '3-5 أيام' },
  { name: 'الأقصر', shippingFee: 80, deliveryDays: '3-5 أيام' },
  { name: 'أسوان', shippingFee: 80, deliveryDays: '3-5 أيام' },
  { name: 'البحر الأحمر (الغردقة)', shippingFee: 85, deliveryDays: '3-5 أيام' }
];

export const FREE_SHIPPING_THRESHOLD = 1500;
