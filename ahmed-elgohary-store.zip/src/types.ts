export type ProductCategory = 'all' | 'men' | 'women' | 'hoodies' | 'jackets' | 'tshirts' | 'pants' | 'sets' | 'offers';
export type TargetGender = 'men' | 'women' | 'unisex';

export interface ProductColor {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  nameEn: string;
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
  category: ProductCategory;
  gender: TargetGender;
  sizes: string[];
  colors: ProductColor[];
  images: string[];
  description: string;
  fabric: string;
  fit: string;
  care: string;
  isBestSeller?: boolean;
  isNew?: boolean;
  isOffer?: boolean;
  rating: number;
  reviewsCount: number;
  stockCount: number;
}

export interface CartItem {
  cartItemId: string;
  product: Product;
  selectedSize: string;
  selectedColor: ProductColor;
  quantity: number;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  secondPhone?: string;
  governorate: string;
  address: string;
  notes?: string;
  paymentMethod: 'cod' | 'vodafone_cash' | 'instapay' | 'card';
}

export interface Order {
  id: string;
  customer: CustomerInfo;
  items: CartItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  date: string;
  status: 'confirmed' | 'processing' | 'shipped';
}

export interface CustomerReview {
  id: string;
  author: string;
  city: string;
  rating: number;
  comment: string;
  productPurchased: string;
  date: string;
  verified: boolean;
}

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type?: 'success' | 'info' | 'warning';
}
