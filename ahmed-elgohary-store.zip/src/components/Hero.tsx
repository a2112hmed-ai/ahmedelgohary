import React from 'react';
import { ArrowLeft, Sparkles, ShieldCheck, Truck, RefreshCw } from 'lucide-react';
import { heroImg } from '../data/products';

interface HeroProps {
  onShopClick: () => void;
  onOffersClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopClick, onOffersClick }) => {
  return (
    <section className="relative overflow-hidden bg-[#0c0c0e] border-b border-neutral-800">
      {/* Background Hero Image with atmospheric overlays */}
      <div className="relative min-h-[580px] lg:min-h-[680px] flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src={heroImg}
            alt="Ahmed Elgohary Luxury Streetwear Collection"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center lg:object-[center_25%] opacity-45 scale-[1.02] transform transition-transform duration-1000"
            onError={(e) => {
              // Resilient fallback styling
              const target = e.currentTarget as HTMLImageElement;
              target.style.display = 'none';
            }}
          />
          {/* Subtle gradient overlays to guarantee WCAG AA readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-[#0c0c0e]/75 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#0c0c0e] via-[#0c0c0e]/80 to-transparent"></div>
          {/* Subtle warm luxury glow */}
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 w-full">
          <div className="max-w-2xl text-right">
            {/* Sub-headline Kicker (Unboxed text as per Zero-Pill Discipline) */}
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-4 tracking-wider uppercase">
              <span className="w-6 h-px bg-amber-400"></span>
              <span>كولكشن شتاء 2025 الحصري</span>
              <span aria-hidden="true">·</span>
              <span className="text-neutral-400">تصميم وإشراف Ahmed Elgohary</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.2] mb-6 font-display" style={{ textWrap: 'balance' }}>
              اكتشف ستايلك مع{' '}
              <span className="gold-gradient-text inline-block">
                Ahmed Elgohary
              </span>
            </h1>

            {/* Brief Description */}
            <p className="text-base sm:text-lg text-neutral-300 mb-8 leading-relaxed font-normal max-w-xl">
              أزياء شبابية راقية تجمع بين الراحة والجرأة في التصميم. قصات أوفرسايز منتقاة بعناية، وخامات قطنية مصرية معالجة بأعلى المعايير العالمية لتمنحك أناقة استثنائية تدوم.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={onShopClick}
                className="group relative inline-flex items-center justify-center gap-3 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-bold px-7 py-3.5 rounded-lg transition-all shadow-lg shadow-amber-500/20 active:scale-[0.98] cursor-pointer"
              >
                <span>تسوق الآن</span>
                <ArrowLeft size={18} className="transform group-hover:-translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOffersClick}
                className="inline-flex items-center justify-center gap-2 bg-neutral-900/80 hover:bg-neutral-800 text-white font-semibold px-6 py-3.5 rounded-lg border border-neutral-700/80 hover:border-amber-500/40 transition-all cursor-pointer backdrop-blur-sm"
              >
                <Sparkles size={16} className="text-amber-400" />
                <span>عروض وخصومات حصرية</span>
              </button>
            </div>

            {/* Trust Badges - Unboxed quiet layout */}
            <div className="mt-12 pt-8 border-t border-neutral-800/80 grid grid-cols-3 gap-4 text-neutral-400 text-xs">
              <div className="flex items-center gap-2.5">
                <ShieldCheck size={20} className="text-amber-400 shrink-0" />
                <div>
                  <div className="font-semibold text-neutral-200">قطن 100% ممتاز</div>
                  <div className="text-[11px] text-neutral-500">خامات معالجة ضد الوبرة</div>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <Truck size={20} className="text-amber-400 shrink-0" />
                <div>
                  <div className="font-semibold text-neutral-200">شحن سريع 24-48 ساعة</div>
                  <div className="text-[11px] text-neutral-500">توصيل لكافة المحافظات</div>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <RefreshCw size={20} className="text-amber-400 shrink-0" />
                <div>
                  <div className="font-semibold text-neutral-200">معاينة واستبدال سهل</div>
                  <div className="text-[11px] text-neutral-500">حق المعاينة مع المندوب</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
