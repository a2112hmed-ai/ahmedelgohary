import React, { useState } from 'react';
import { Star, CheckCircle, MessageSquarePlus, ThumbsUp, Send } from 'lucide-react';
import { CustomerReview } from '../types';

interface ReviewsSectionProps {
  reviews: CustomerReview[];
  onAddReview: (review: CustomerReview) => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ reviews, onAddReview }) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [author, setAuthor] = useState('');
  const [city, setCity] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [productPurchased, setProductPurchased] = useState('هودي أوفرسايز فخم أسود كربوني');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!author.trim() || !comment.trim()) return;

    const newRev: CustomerReview = {
      id: `rev-${Date.now()}`,
      author: author.trim(),
      city: city.trim() || 'القاهرة',
      rating,
      comment: comment.trim(),
      productPurchased,
      date: 'الآن',
      verified: true
    };

    onAddReview(newRev);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setShowAddForm(false);
      setAuthor('');
      setCity('');
      setComment('');
    }, 1800);
  };

  return (
    <section id="reviews" className="py-20 bg-[#0d0d10] border-t border-neutral-800 text-right">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
              تجارب حقيقية · عملاء Ahmed Elgohary
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
              ماذا يقول عملاؤنا عن التجربة؟
            </h2>
            <p className="text-sm text-neutral-400 mt-2 max-w-xl">
              نفخر بثقة آلاف الشباب ومحبي الموضة الراقية في جميع أنحاء مصر، ونلتزم دائماً بتقديم أرقى الخامات وأفضل خدمة.
            </p>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="self-start md:self-auto inline-flex items-center gap-2 bg-neutral-900 hover:bg-neutral-850 text-white font-semibold text-xs px-4 py-2.5 rounded-lg border border-neutral-700/80 hover:border-amber-500/50 transition-colors"
          >
            <MessageSquarePlus size={16} className="text-amber-400" />
            <span>شاركنا برأيك وتجربتك</span>
          </button>
        </div>

        {/* Add Review Form */}
        {showAddForm && (
          <div className="bg-[#121217] border border-amber-500/20 rounded-xl p-5 sm:p-6 mb-10 max-w-2xl mx-auto">
            <h3 className="text-base font-bold text-white mb-4">كتابة تقييم جديد</h3>
            {submitted ? (
              <div className="p-4 bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 text-sm rounded-lg text-center font-bold">
                شكراً لمشاركتك! تم إضافة تقييمك بنجاح.
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-neutral-300 mb-1">اسمك بالكامل</label>
                    <input
                      type="text"
                      required
                      value={author}
                      onChange={(e) => setAuthor(e.target.value)}
                      placeholder="أحمد علي"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="block text-neutral-300 mb-1">المدينة / المحافظة</label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="مدينة نصر، القاهرة"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-neutral-300 mb-1">القطعة المشتراة</label>
                    <input
                      type="text"
                      value={productPurchased}
                      onChange={(e) => setProductPurchased(e.target.value)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="block text-neutral-300 mb-1">تقييمك (من 1 إلى 5)</label>
                    <div className="flex items-center gap-2 pt-1.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setRating(star)}
                          className="focus:outline-none"
                        >
                          <Star
                            size={20}
                            className={
                              star <= rating
                                ? 'fill-amber-400 text-amber-400'
                                : 'text-neutral-600'
                            }
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-neutral-300 mb-1">رأيك وتفاصيل تجربتك مع الخامة والتوصيل</label>
                  <textarea
                    rows={3}
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="اكتب تجربتك بكل صراحة..."
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-4 py-2 bg-neutral-800 text-neutral-300 rounded-lg hover:bg-neutral-700"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-black font-bold rounded-lg flex items-center gap-1.5"
                  >
                    <Send size={14} />
                    <span>نشر التقييم</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#111114] border border-neutral-800 rounded-xl p-5 flex flex-col justify-between hover:border-neutral-700 transition-colors"
            >
              <div>
                {/* Rating & Verified badge */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        size={14}
                        className={
                          i < rev.rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-neutral-700'
                        }
                      />
                    ))}
                  </div>
                  {rev.verified && (
                    <span className="flex items-center gap-1 text-[11px] text-emerald-400">
                      <CheckCircle size={12} />
                      <span>مشتري موثق</span>
                    </span>
                  )}
                </div>

                {/* Comment */}
                <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-4">
                  "{rev.comment}"
                </p>
              </div>

              {/* Author & Product Info */}
              <div className="pt-3 border-t border-neutral-800/80">
                <div className="font-bold text-xs text-white">{rev.author}</div>
                <div className="text-[11px] text-neutral-500 mt-0.5">{rev.city}</div>
                <div className="text-[10px] text-amber-400/80 mt-1 truncate">
                  المنتج: {rev.productPurchased}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
