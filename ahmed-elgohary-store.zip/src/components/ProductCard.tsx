import React, { useState } from 'react';
import { ShoppingBag, Eye, Heart, Star, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOpenDetails: (product: Product) => void;
  onQuickAdd: (product: Product, size: string, color: { name: string; hex: string }) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenDetails,
  onQuickAdd,
  isWishlisted,
  onToggleWishlist
}) => {
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'L');
  const [selectedColor, setSelectedColor] = useState(product.colors[0] || { name: 'أسود', hex: '#111' });
  const [isHovered, setIsHovered] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const displayImage = isHovered && product.images.length > 1 ? product.images[1] : product.images[0];

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAdd(product, selectedSize, selectedColor);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1200);
  };

  const getGenderLabel = (gender: string) => {
    switch (gender) {
      case 'men':
        return 'رجالي';
      case 'women':
        return 'حريمي';
      default:
        return 'يونيسكس';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'hoodies':
        return 'هوديز وسويت شيرت';
      case 'jackets':
        return 'جواكت ومعاطف';
      case 'tshirts':
        return 'تيشيرتات صيفية';
      case 'pants':
        return 'بناطيل وكارجو';
      case 'sets':
        return 'أطقم وبدلات';
      default:
        return 'أزياء راقية';
    }
  };

  return (
    <div
      onClick={() => onOpenDetails(product)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative flex flex-col bg-[#111114] border border-neutral-800/80 hover:border-neutral-700 rounded-xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/50 cursor-pointer"
    >
      {/* Product Image Container */}
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-neutral-900">
        <img
          src={displayImage}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
          onError={(e) => {
            const target = e.currentTarget as HTMLImageElement;
            target.style.display = 'none';
          }}
        />

        {/* Resilient fallback backdrop in case image fails */}
        <div className="absolute inset-0 -z-10 flex flex-col items-center justify-center bg-neutral-900 text-neutral-600 p-4 text-center">
          <span className="text-2xl font-bold font-display text-amber-500/40">Ahmed Elgohary</span>
          <span className="text-xs text-neutral-500 mt-1">{product.name}</span>
        </div>

        {/* Subtle top metadata / discount tag */}
        <div className="absolute top-3 right-3 left-3 flex items-center justify-between pointer-events-none">
          {product.discountPercentage ? (
            <span className="bg-amber-500 text-black text-[11px] font-black px-2 py-0.5 rounded shadow-sm">
              خصم {product.discountPercentage}%
            </span>
          ) : product.isNew ? (
            <span className="bg-neutral-800/90 text-amber-300 border border-amber-500/20 text-[11px] font-bold px-2 py-0.5 rounded backdrop-blur-xs">
              جديد
            </span>
          ) : <span />}

          {/* Wishlist toggle */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product.id);
            }}
            aria-label="إضافة للمفضلة"
            className="pointer-events-auto w-8 h-8 rounded-full bg-black/60 backdrop-blur-md border border-neutral-700/60 flex items-center justify-center text-neutral-300 hover:text-red-400 transition-colors"
          >
            <Heart
              size={15}
              className={isWishlisted ? 'fill-red-500 text-red-500' : ''}
            />
          </button>
        </div>

        {/* Quick View Button overlay on hover */}
        <div className="absolute inset-x-3 bottom-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetails(product);
            }}
            className="flex-1 bg-black/80 backdrop-blur-md hover:bg-black text-white text-xs font-semibold py-2 px-3 rounded-lg border border-neutral-700/80 flex items-center justify-center gap-1.5 transition-colors"
          >
            <Eye size={14} className="text-amber-400" />
            <span>عرض التفاصيل</span>
          </button>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex flex-col flex-1 text-right">
        {/* Unboxed Metadata (Zero-Pill Discipline) */}
        <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1.5 font-medium">
          <span>{getCategoryLabel(product.category)}</span>
          <span aria-hidden="true" className="text-neutral-600">·</span>
          <span>{getGenderLabel(product.gender)}</span>
          {product.isBestSeller && (
            <>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <span className="text-amber-400 font-semibold">الأكثر مبيعاً</span>
            </>
          )}
        </div>

        {/* Product Title */}
        <h3 className="font-semibold text-white text-sm sm:text-base line-clamp-1 mb-1 group-hover:text-amber-300 transition-colors">
          {product.name}
        </h3>

        {/* Price Row (Tabular numbers) */}
        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-lg font-bold text-amber-400 font-display tabular-nums">
            {product.price.toLocaleString('ar-EG')} ج.م
          </span>
          {product.originalPrice && (
            <span className="text-xs text-neutral-500 line-through tabular-nums font-display">
              {product.originalPrice.toLocaleString('ar-EG')} ج.م
            </span>
          )}
        </div>

        {/* Sizes and Colors quick selectors */}
        <div className="mt-auto pt-3 border-t border-neutral-800/80 space-y-2.5">
          {/* Colors palette */}
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-neutral-400">الألوان:</span>
            <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setSelectedColor(c)}
                  title={c.name}
                  aria-label={c.name}
                  className={`w-4 h-4 rounded-full transition-transform ${
                    selectedColor.name === c.name
                      ? 'ring-2 ring-amber-400 ring-offset-2 ring-offset-neutral-900 scale-110'
                      : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>

          {/* Sizes */}
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-neutral-400">المقاسات:</span>
            <div className="flex items-center gap-1 overflow-x-auto py-0.5" onClick={(e) => e.stopPropagation()}>
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedSize(s)}
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded transition-colors ${
                    selectedSize === s
                      ? 'bg-amber-400 text-black font-black'
                      : 'bg-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Add to Cart button */}
          <button
            onClick={handleAddToCart}
            className={`w-full mt-2 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              addedAnimation
                ? 'bg-emerald-600 text-white'
                : 'bg-neutral-800 hover:bg-amber-500 hover:text-black text-neutral-200 border border-neutral-700/60 hover:border-transparent'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check size={14} />
                <span>تمت الإضافة للسلة</span>
              </>
            ) : (
              <>
                <ShoppingBag size={14} />
                <span>أضف إلى السلة</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
