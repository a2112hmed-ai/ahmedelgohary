import React, { useState } from 'react';
import { X, Trash2, ArrowLeft, ShoppingBag, Truck, Tag, Check } from 'lucide-react';
import { CartItem } from '../types';
import { FREE_SHIPPING_THRESHOLD } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQuantity: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onProceedToCheckout: () => void;
  discountAmount: number;
  onApplyPromoCode: (code: string) => { success: boolean; message: string };
  appliedPromo: string | null;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  discountAmount,
  onApplyPromoCode,
  appliedPromo
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [promoFeedback, setPromoFeedback] = useState<{ text: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const freeShippingProgress = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));

  const finalTotal = Math.max(0, subtotal - discountAmount);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    const res = onApplyPromoCode(promoInput.trim());
    if (res.success) {
      setPromoFeedback({ text: res.message });
    } else {
      setPromoFeedback({ text: res.message, isError: true });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-xs transition-opacity duration-300"
      />

      {/* Drawer Panel (RTL: opens from right or left; left is conventional for cart drawers in RTL e-commerce or right side) */}
      <div className="fixed inset-y-0 left-0 max-w-full flex pl-0 z-50">
        <div className="w-screen max-w-md bg-[#101014] border-r border-neutral-800 text-right flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
              aria-label="إغلاق السلة"
            >
              <X size={20} />
            </button>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-white">سلة المشتريات</span>
              <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-mono font-bold">
                {items.reduce((s, i) => s + i.quantity, 0)}
              </span>
            </div>
          </div>

          {/* Free Shipping Progress Indicator */}
          <div className="px-5 py-3 bg-neutral-900 border-b border-neutral-800">
            <div className="flex items-center gap-2 text-xs mb-1.5">
              <Truck size={15} className="text-amber-400 shrink-0" />
              {remainingForFreeShipping > 0 ? (
                <span className="text-neutral-300">
                  أضف بـ{' '}
                  <span className="text-amber-400 font-bold tabular-nums">
                    {remainingForFreeShipping.toLocaleString('ar-EG')} ج.م
                  </span>{' '}
                  لتحصل على <span className="font-bold text-white">شحن مجاني</span>!
                </span>
              ) : (
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <Check size={14} />
                  تهانينا! طلبيتك مؤهلة للشحن المجاني
                </span>
              )}
            </div>
            <div className="w-full bg-neutral-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-amber-400 h-full rounded-full transition-all duration-500"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Item List / Empty State */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12 text-neutral-400">
                <div className="w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mb-4 text-neutral-500">
                  <ShoppingBag size={28} />
                </div>
                <h3 className="text-base font-bold text-white mb-1">سلة المشتريات فارغة</h3>
                <p className="text-xs text-neutral-400 max-w-xs mb-6">
                  لم تقم بإضافة أي قطع بعد. استكشف كولكشن أحمد الجوهري واختر القطع التي تناسب أسلوبك.
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-amber-400 text-black font-bold text-xs rounded-lg hover:bg-amber-300 transition-colors"
                >
                  تصفح المنتجات الآن
                </button>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.cartItemId}
                  className="flex gap-3 bg-neutral-900/70 border border-neutral-800/80 rounded-xl p-3 relative group"
                >
                  {/* Thumbnail */}
                  <div className="w-20 h-24 rounded-lg overflow-hidden bg-neutral-850 shrink-0 border border-neutral-800">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Info */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => onRemoveItem(item.cartItemId)}
                          className="text-neutral-500 hover:text-red-400 p-1 transition-colors"
                          title="حذف من السلة"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>

                      {/* Selected options */}
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-neutral-400">
                        <span>المقاس: <strong className="text-neutral-200">{item.selectedSize}</strong></span>
                        <span aria-hidden="true">·</span>
                        <span className="flex items-center gap-1">
                          <span>اللون:</span>
                          <span
                            className="w-2.5 h-2.5 rounded-full inline-block border border-white/20"
                            style={{ backgroundColor: item.selectedColor.hex }}
                          />
                          <strong className="text-neutral-200">{item.selectedColor.name}</strong>
                        </span>
                      </div>
                    </div>

                    {/* Price & Quantity Stepper */}
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-neutral-800/60">
                      <div className="text-xs font-bold text-amber-400 font-display tabular-nums">
                        {(item.product.price * item.quantity).toLocaleString('ar-EG')} ج.م
                      </div>

                      <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded-md">
                        <button
                          onClick={() => onUpdateQuantity(item.cartItemId, item.quantity - 1)}
                          className="w-6 h-6 flex items-center justify-center text-neutral-400 hover:text-white"
                        >
                          -
                        </button>
                        <span className="w-7 text-center text-xs font-mono font-bold text-white tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.cartItemId, item.quantity + 1)}
                          className="w-6 h-6 flex items-center justify-center text-neutral-400 hover:text-white"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Action */}
          {items.length > 0 && (
            <div className="p-5 bg-neutral-950 border-t border-neutral-800 space-y-4">
              {/* Promo Code Input */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value)}
                  placeholder="كود الخصم (مثال: GOHARY10)"
                  className="flex-1 bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 uppercase"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs rounded-lg transition-colors"
                >
                  تطبيق
                </button>
              </form>

              {promoFeedback && (
                <div
                  className={`text-xs ${
                    promoFeedback.isError ? 'text-red-400' : 'text-emerald-400 font-bold'
                  }`}
                >
                  {promoFeedback.text}
                </div>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-neutral-400 pt-2 border-t border-neutral-800/80">
                <div className="flex justify-between">
                  <span>المجموع الفرعي:</span>
                  <span className="font-mono text-neutral-200 tabular-nums">
                    {subtotal.toLocaleString('ar-EG')} ج.م
                  </span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400 font-medium">
                    <span>الخصم المطبق ({appliedPromo}):</span>
                    <span className="font-mono tabular-nums">
                      - {discountAmount.toLocaleString('ar-EG')} ج.م
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>الشحن:</span>
                  <span className="text-amber-400 font-medium">
                    {subtotal >= FREE_SHIPPING_THRESHOLD ? 'مجاني' : 'يُحدد في خطوة العنوان'}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-neutral-800">
                  <span>الإجمالي التقريبي:</span>
                  <span className="text-amber-400 font-display tabular-nums">
                    {finalTotal.toLocaleString('ar-EG')} ج.م
                  </span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={onProceedToCheckout}
                className="w-full py-3.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold text-sm rounded-lg shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>متابعة إتمام الطلب</span>
                <ArrowLeft size={18} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
