import React, { useEffect } from 'react';
import { CheckCircle2, Info, AlertTriangle, X } from 'lucide-react';
import { ToastMessage } from '../types';

interface ToastProps {
  toast: ToastMessage | null;
  onDismiss: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => {
      onDismiss();
    }, 3500);
    return () => clearTimeout(timer);
  }, [toast, onDismiss]);

  if (!toast) return null;

  return (
    <div className="fixed bottom-6 left-6 z-50 max-w-sm w-full bg-[#141419] border border-amber-500/30 text-white rounded-xl shadow-2xl p-4 text-right flex items-start gap-3 animate-slide-up">
      <button
        onClick={onDismiss}
        className="text-neutral-400 hover:text-white p-0.5 shrink-0"
        aria-label="إغلاق"
      >
        <X size={15} />
      </button>

      <div className="flex-1">
        <div className="text-xs font-bold text-white flex items-center gap-1.5 justify-end mb-0.5">
          <span>{toast.title}</span>
          <CheckCircle2 size={16} className="text-amber-400 shrink-0" />
        </div>
        <p className="text-[11px] text-neutral-300 leading-normal">
          {toast.message}
        </p>
      </div>
    </div>
  );
};
