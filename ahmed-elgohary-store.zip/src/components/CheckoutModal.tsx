import React, { useState } from 'react';
import { X, CheckCircle, ShieldCheck, Truck, CreditCard, Banknote, Phone, ArrowLeft, AlertCircle } from 'lucide-react';
import { CartItem, CustomerInfo, Order } from '../types';
import { EGYPT_GOVERNORATES, FREE_SHIPPING_THRESHOLD } from '../data/products';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  discountAmount: number;
  onCompleteOrder: (order: Order) => void;
  onClearCart: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  discountAmount,
  onCompleteOrder,
  onClearCart
}) => {
  if (!isOpen) return null;

  const [formData, setFormData] = useState<CustomerInfo>({
    name: '',
    phone: '',
    secondPhone: '',
    governorate: 'القاهرة',
    address: '',
    notes: '',
    paymentMethod: 'cod'
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const selectedGovObj = EGYPT_GOVERNORATES.find((g) => g.name.includes(formData.governorate)) || EGYPT_GOVERNORATES[0];
  const shippingFee = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : selectedGovObj.shippingFee;
  const total = Math.max(0, subtotal - discountAmount + shippingFee);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim() || formData.name.trim().length < 3) {
      newErrors.name = 'يرجى كتابة الاسم الثلاثي بالكامل';
    }
    const phoneRegex = /^01[0125][0-9]{8}$/;
    if (!formData.phone.trim()) {
      newErrors.phone = 'رقم الهاتف مطلوب للتواصل مع المندوب';
    } else if (!phoneRegex.test(formData.phone.trim())) {
      newErrors.phone = 'يرجى إدخال رقم هاتف مصري صحيح (11 رقم يبدأ بـ 01)';
    }

    if (!formData.address.trim() || formData.address.trim().length < 8) {
      newErrors.address = 'يرجى كتابة العنوان التفصيلي (المنطقة، الشارع، العمارة، الشقة)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const orderId = `AE-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder: Order = {
      id: orderId,
      customer: formData,
      items: [...items],
      subtotal,
      shipping: shippingFee,
      discount: discountAmount,
      total,
      date: new Date().toLocaleDateString('ar-EG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }),
      status: 'confirmed'
    };

    setConfirmedOrder(newOrder);
    onCompleteOrder(newOrder);
    onClearCart();
  };

  const handleWhatsAppSendOrder = () => {
    if (!confirmedOrder) return;
    const msg = `مرحباً أستاذ أحمد الجوهري، قمت بتأكيد طلب جديد من الموقع:
- رقم الطلب: ${confirmedOrder.id}
- الاسم: ${confirmedOrder.customer.name}
- الهاتف: ${confirmedOrder.customer.phone}
- المحافظة والعنوان: ${confirmedOrder.customer.governorate} - ${confirmedOrder.customer.address}
- عدد القطع: ${confirmedOrder.items.length}
- طريقة الدفع: ${
      confirmedOrder.customer.paymentMethod === 'cod'
        ? 'الدفع عند الاستلام'
        : confirmedOrder.customer.paymentMethod === 'instapay'
        ? 'إنستاباي / فودافون كاش'
        : 'بطاقة بنكية'
    }
- الإجمالي: ${confirmedOrder.total.toLocaleString('ar-EG')} ج.م
أرجو تأكيد الشحن!`;

    window.open(`https://wa.me/201020304050?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#111115] border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto text-right">
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X size={20} />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-amber-400 font-display">Ahmed Elgohary</span>
            <span className="text-white font-bold text-base">| إتمام عملية الشراء</span>
          </div>
        </div>

        {confirmedOrder ? (
          /* Order Confirmation Success State */
          <div className="p-6 sm:p-10 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
              <CheckCircle size={36} />
            </div>

            <div>
              <h3 className="text-2xl font-black text-white mb-2 font-display">
                تم استلام طلبك بنجاح!
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 max-w-md mx-auto">
                شكراً لاختيارك علامة Ahmed Elgohary. سيتم التواصل معك هاتفياً أو عبر الواتساب لتأكيد موعد التسليم والشحن.
              </p>
            </div>

            {/* Order Card Summary */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 text-right max-w-lg mx-auto text-xs space-y-3">
              <div className="flex justify-between items-center pb-2 border-b border-neutral-800">
                <span className="text-neutral-400">رقم الطلب:</span>
                <span className="font-mono font-bold text-amber-400 text-sm">{confirmedOrder.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">العميل:</span>
                <span className="text-white font-semibold">{confirmedOrder.customer.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">رقم الهاتف:</span>
                <span className="font-mono text-white">{confirmedOrder.customer.phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">عنوان التوصيل:</span>
                <span className="text-white">{confirmedOrder.customer.governorate} - {confirmedOrder.customer.address}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">موعد التسليم المتوقع:</span>
                <span className="text-neutral-200">{selectedGovObj.deliveryDays}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-neutral-800 text-sm font-bold">
                <span className="text-white">المبلغ المطلوب سداده:</span>
                <span className="text-amber-400 font-display tabular-nums">
                  {confirmedOrder.total.toLocaleString('ar-EG')} ج.م
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                onClick={handleWhatsAppSendOrder}
                className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Phone size={16} />
                <span>إرسال تفاصيل الطلب لمسؤول المبيعات على الواتساب</span>
              </button>

              <button
                onClick={onClose}
                className="w-full sm:w-auto px-6 py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-medium text-xs rounded-lg transition-colors cursor-pointer"
              >
                العودة للتسوق
              </button>
            </div>
          </div>
        ) : (
          /* Checkout Form */
          <form onSubmit={handleSubmit} className="p-5 sm:p-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Customer Info Column */}
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-white flex items-center gap-2 pb-2 border-b border-neutral-800">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span>بيانات العميل والشحن</span>
                </h4>

                {/* Name */}
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                    الاسم بالكامل <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="مثال: أحمد محمد علي"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  />
                  {errors.name && <p className="text-red-400 text-[11px] mt-1">{errors.name}</p>}
                </div>

                {/* Phone & Second Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                      رقم الهاتف (الواتساب) <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="01012345678"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 font-mono text-left"
                    />
                    {errors.phone && <p className="text-red-400 text-[11px] mt-1">{errors.phone}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                      رقم هاتف بديل (اختياري)
                    </label>
                    <input
                      type="tel"
                      value={formData.secondPhone}
                      onChange={(e) => setFormData({ ...formData, secondPhone: e.target.value })}
                      placeholder="01234567890"
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 font-mono text-left"
                    />
                  </div>
                </div>

                {/* Governorate */}
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                    المحافظة <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={formData.governorate}
                    onChange={(e) => setFormData({ ...formData, governorate: e.target.value })}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    {EGYPT_GOVERNORATES.map((gov) => (
                      <option key={gov.name} value={gov.name}>
                        {gov.name} — مصاريف الشحن: {gov.shippingFee} ج.م ({gov.deliveryDays})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Address */}
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                    العنوان بالتفصيل <span className="text-red-400">*</span>
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="اسم الحي أو المنطقة، اسم الشارع، رقم العقار، الدور، الشقة..."
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  />
                  {errors.address && <p className="text-red-400 text-[11px] mt-1">{errors.address}</p>}
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                    ملاحظات التوصيل (اختياري)
                  </label>
                  <input
                    type="text"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="التسليم بعد الساعة 4 مساءً، أو الاتصال قبل الوصول..."
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Payment & Order Summary Column */}
              <div className="space-y-4 flex flex-col justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2 pb-2 border-b border-neutral-800">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span>طريقة الدفع وملخص الحساب</span>
                  </h4>

                  {/* Payment Methods */}
                  <div className="space-y-2 mt-3">
                    <label
                      onClick={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        formData.paymentMethod === 'cod'
                          ? 'border-amber-400 bg-neutral-900 text-white'
                          : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Banknote size={18} className="text-amber-400" />
                        <div>
                          <div className="font-bold text-xs">الدفع عند الاستلام (COD)</div>
                          <div className="text-[11px] text-neutral-500">ادفع نقداً للمندوب بعد معاينة طلبيتك</div>
                        </div>
                      </div>
                      <input
                        type="radio"
                        name="payment"
                        checked={formData.paymentMethod === 'cod'}
                        onChange={() => {}}
                        className="accent-amber-400"
                      />
                    </label>

                    <label
                      onClick={() => setFormData({ ...formData, paymentMethod: 'instapay' })}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        formData.paymentMethod === 'instapay'
                          ? 'border-amber-400 bg-neutral-900 text-white'
                          : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Phone size={18} className="text-emerald-400" />
                        <div>
                          <div className="font-bold text-xs">إنستاباي / فودافون كاش</div>
                          <div className="text-[11px] text-neutral-500">تحويل فوري وسريع (تأكيد لحظي)</div>
                        </div>
                      </div>
                      <input
                        type="radio"
                        name="payment"
                        checked={formData.paymentMethod === 'instapay'}
                        onChange={() => {}}
                        className="accent-amber-400"
                      />
                    </label>

                    <label
                      onClick={() => setFormData({ ...formData, paymentMethod: 'card' })}
                      className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                        formData.paymentMethod === 'card'
                          ? 'border-amber-400 bg-neutral-900 text-white'
                          : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <CreditCard size={18} className="text-blue-400" />
                        <div>
                          <div className="font-bold text-xs">بطاقة ائتمان / فيزا وميزة</div>
                          <div className="text-[11px] text-neutral-500">دفع إلكتروني آمن ومشفر 100%</div>
                        </div>
                      </div>
                      <input
                        type="radio"
                        name="payment"
                        checked={formData.paymentMethod === 'card'}
                        onChange={() => {}}
                        className="accent-amber-400"
                      />
                    </label>
                  </div>

                  {/* Summary Box */}
                  <div className="mt-4 bg-neutral-900/80 border border-neutral-800 rounded-xl p-4 space-y-2 text-xs text-neutral-300">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">إجمالي المنتجات ({items.length} قطع):</span>
                      <span className="font-mono tabular-nums">{subtotal.toLocaleString('ar-EG')} ج.م</span>
                    </div>

                    {discountAmount > 0 && (
                      <div className="flex justify-between text-emerald-400 font-semibold">
                        <span>قيمة الخصم:</span>
                        <span className="font-mono tabular-nums">- {discountAmount.toLocaleString('ar-EG')} ج.م</span>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <span className="text-neutral-400">تكلفة الشحن إلى {formData.governorate}:</span>
                      <span className="font-semibold text-white">
                        {shippingFee === 0 ? (
                          <span className="text-emerald-400 font-bold">مجاني</span>
                        ) : (
                          `${shippingFee.toLocaleString('ar-EG')} ج.م`
                        )}
                      </span>
                    </div>

                    <div className="flex justify-between text-base font-black text-white pt-3 border-t border-neutral-800">
                      <span>المبلغ الإجمالي النهائي:</span>
                      <span className="text-amber-400 font-display tabular-nums">
                        {total.toLocaleString('ar-EG')} ج.م
                      </span>
                    </div>
                  </div>
                </div>

                {/* Submit button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold text-sm rounded-lg shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <span>تأكيد الطلب الآن</span>
                    <ArrowLeft size={18} />
                  </button>
                  <p className="text-[11px] text-neutral-500 text-center mt-2 flex items-center justify-center gap-1">
                    <ShieldCheck size={14} className="text-amber-400" />
                    <span>تسوق آمن ومضمون 100% مع ضمان استبدال واسترجاع سهل</span>
                  </p>
                </div>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
