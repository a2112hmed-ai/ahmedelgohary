import React from 'react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../types';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds: string[];
  allProducts: Product[];
  onRemoveFromWishlist: (productId: string) => void;
  onOpenProductDetails: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  allProducts,
  onRemoveFromWishlist,
  onOpenProductDetails
}) => {
  if (!isOpen) return null;

  const wishedProducts = allProducts.filter((p) => wishlistIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-xs transition-opacity duration-300"
      />

      <div className="fixed inset-y-0 left-0 max-w-full flex pl-0 z-50">
        <div className="w-screen max-w-md bg-[#101014] border-r border-neutral-800 text-right flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-5 border-b border-neutral-800 flex items-center justify-between">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            >
              <X size={20} />
            </button>
            <div className="flex items-center gap-2">
              <span className="font-bold text-lg text-white">قائمة المفضلة</span>
              <Heart size={18} className="fill-amber-400 text-amber-400" />
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {wishedProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12 text-neutral-400">
                <div className="w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mb-4 text-neutral-500">
                  <Heart size={28} />
                </div>
                <h3 className="text-base font-bold text-white mb-1">قائمتك المفضلة فارغة</h3>
                <p className="text-xs text-neutral-400 max-w-xs mb-6">
                  اضغط على رمز القلب عند أي منتج لحفظه والرجوع إليه لاحقاً.
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-amber-400 text-black font-bold text-xs rounded-lg hover:bg-amber-300 transition-colors"
                >
                  استكشاف الملابس
                </button>
              </div>
            ) : (
              wishedProducts.map((p) => (
                <div
                  key={p.id}
                  className="flex gap-3 bg-neutral-900/70 border border-neutral-800/80 rounded-xl p-3 items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-20 rounded-lg overflow-hidden bg-neutral-850 shrink-0">
                      <img
                        src={p.images[0]}
                        alt={p.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white line-clamp-1">{p.name}</h4>
                      <div className="text-xs font-bold text-amber-400 font-display tabular-nums mt-1">
                        {p.price.toLocaleString('ar-EG')} ج.م
                      </div>
                      <button
                        onClick={() => {
                          onClose();
                          onOpenProductDetails(p);
                        }}
                        className="text-[11px] text-amber-400 hover:underline mt-1 block font-medium"
                      >
                        عرض وتحديد المقاس &larr;
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveFromWishlist(p.id)}
                    className="p-2 text-neutral-500 hover:text-red-400 transition-colors"
                    title="حذف من المفضلة"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
