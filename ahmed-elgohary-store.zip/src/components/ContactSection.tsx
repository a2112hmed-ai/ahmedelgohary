import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageSquare, Send, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    setSent(true);
    setTimeout(() => {
      setSent(false);
      setName('');
      setPhone('');
      setMessage('');
    }, 2500);
  };

  const handleDirectWhatsApp = () => {
    window.open('https://wa.me/201020304050?text=مرحباً، أود الاستفسار بخصوص منتجات Ahmed Elgohary', '_blank');
  };

  return (
    <section id="contact" className="py-20 bg-[#0e0e12] border-t border-neutral-800 text-right">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
            خدمة العملاء · فريق الدعم
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white font-display">
            تواصل معنا بكل سهولة
          </h2>
          <p className="text-sm text-neutral-400 mt-2">
            يسعدنا الرد على جميع استفساراتكم بخصوص المقاسات، الطلبات الخاصة، ومواعيد الشحن والتوصيل.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Details Cards */}
          <div className="space-y-4">
            {/* Phone & WhatsApp Card */}
            <div className="bg-[#121217] border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-lg">
                  <Phone size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">الهاتف والواتساب</h3>
                  <div className="text-xs text-neutral-400">متاحون للرد السريع طوال اليوم</div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between pt-2 border-t border-neutral-800/80">
                <span className="font-mono text-white text-sm dir-ltr">01020304050</span>
                <button
                  onClick={handleDirectWhatsApp}
                  className="text-xs text-emerald-400 hover:underline font-bold"
                >
                  مراسلة واتساب
                </button>
              </div>
            </div>

            {/* Showroom & Address Card */}
            <div className="bg-[#121217] border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-lg">
                  <MapPin size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">معرض الملابس والمقر الرئيسي</h3>
                  <div className="text-xs text-neutral-400">القاهرة، مصر</div>
                </div>
              </div>
              <p className="text-xs text-neutral-300 mt-2 pt-2 border-t border-neutral-800/80">
                التجمع الخامس، شارع التسعين الشمالي، بجوار ووتر واي، القاهرة الجديدة.
              </p>
            </div>

            {/* Working Hours Card */}
            <div className="bg-[#121217] border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition-colors">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-lg">
                  <Clock size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">ساعات العمل والخدمة</h3>
                  <div className="text-xs text-neutral-400">خدمة يومية متواصلة</div>
                </div>
              </div>
              <p className="text-xs text-neutral-300 mt-2 pt-2 border-t border-neutral-800/80">
                يومياً من الساعة 12:00 ظهراً حتى 11:00 مساءً. الشحن يعمل على مدار الأسبوع.
              </p>
            </div>
          </div>

          {/* Direct Message Form (takes 2 cols on lg) */}
          <div className="lg:col-span-2 bg-[#121217] border border-neutral-800 rounded-2xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-white font-bold text-base mb-1">
                <MessageSquare size={18} className="text-amber-400" />
                <span>أرسل لنا استفسارك مباشرة</span>
              </div>
              <p className="text-xs text-neutral-400 mb-6">
                سيقوم ممثل خدمة العملاء بالرد عليك خلال دقائق عبر الهاتف أو الواتساب.
              </p>

              {sent ? (
                <div className="p-8 text-center bg-emerald-950/40 border border-emerald-500/30 rounded-xl space-y-3">
                  <CheckCircle2 size={36} className="text-emerald-400 mx-auto" />
                  <h4 className="text-lg font-bold text-white">تم إرسال رسالتك بنجاح!</h4>
                  <p className="text-xs text-neutral-300">
                    شكراً لتواصلك مع Ahmed Elgohary، سنتواصل معك في أسرع وقت.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-neutral-300 mb-1.5 font-medium">الاسم الكريم</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="أدخل اسمك"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-3 text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div>
                      <label className="block text-neutral-300 mb-1.5 font-medium">رقم الهاتف / الواتساب</label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="010xxxxxxxx"
                        className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-3 text-white focus:outline-none focus:border-amber-400 font-mono text-left"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-neutral-300 mb-1.5 font-medium">موضوع الرسالة أو الاستفسار</label>
                    <textarea
                      rows={4}
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="كيف يمكننا مساعدتك اليوم؟ (استفسار عن مقاس، توصيل، أو طلب خاص)..."
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-3 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-bold rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-amber-500/10"
                  >
                    <Send size={16} />
                    <span>إرسال الرسالة الآن</span>
                  </button>
                </form>
              )}
            </div>

            <div className="mt-8 pt-4 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-500">
              <span>جميع البيانات محمية ومخصصة للتواصل المباشر فقط</span>
              <span className="font-mono text-neutral-400">support@ahmedelgohary.com</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
