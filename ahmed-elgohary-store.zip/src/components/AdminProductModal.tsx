import React, { useState } from 'react';
import { X, Plus, Edit3, Trash2, CheckCircle2, Image as ImageIcon } from 'lucide-react';
import { Product, ProductCategory, TargetGender } from '../types';
import { hoodieImg, bomberImg, setImg, modelImg, heroImg } from '../data/products';

interface AdminProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
}

export const AdminProductModal: React.FC<AdminProductModalProps> = ({
  isOpen,
  onClose,
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'list' | 'add'>('list');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [price, setPrice] = useState<number>(950);
  const [originalPrice, setOriginalPrice] = useState<number>(1200);
  const [category, setCategory] = useState<ProductCategory>('hoodies');
  const [gender, setGender] = useState<TargetGender>('men');
  const [description, setDescription] = useState('');
  const [fabric, setFabric] = useState('قطن مصري 100% ميلتون ثقيل 420 جرام');
  const [fit, setFit] = useState('أوفرسايز مريح (Relaxed Oversized Fit)');
  const [selectedImage, setSelectedImage] = useState<string>(hoodieImg);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [sizesInput, setSizesInput] = useState('S, M, L, XL, XXL');
  const [colorsInput, setColorsInput] = useState('أسود:#111, كحلي:#161b26, رمادي:#4a4d52');

  const presetImages = [
    { label: 'هودي فاخر', url: hoodieImg },
    { label: 'بومبر جاكيت', url: bomberImg },
    { label: 'طقم بليزر وبنطلون', url: setImg },
    { label: 'عارض أزياء ستريت', url: modelImg },
    { label: 'كولكشن رئيسي', url: heroImg }
  ];

  const handleStartEdit = (product: Product) => {
    setEditingProduct(product);
    setName(product.name);
    setNameEn(product.nameEn);
    setPrice(product.price);
    setOriginalPrice(product.originalPrice || product.price);
    setCategory(product.category);
    setGender(product.gender);
    setDescription(product.description);
    setFabric(product.fabric);
    setFit(product.fit);
    setSelectedImage(product.images[0]);
    setSizesInput(product.sizes.join(', '));
    setColorsInput(product.colors.map(c => `${c.name}:${c.hex}`).join(', '));
    setActiveTab('add');
  };

  const handleResetForm = () => {
    setEditingProduct(null);
    setName('');
    setNameEn('');
    setPrice(950);
    setOriginalPrice(1200);
    setDescription('');
    setCustomImageUrl('');
    setActiveTab('list');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedSizes = sizesInput.split(',').map(s => s.trim()).filter(Boolean);
    const parsedColors = colorsInput.split(',').map(item => {
      const parts = item.split(':');
      return {
        name: parts[0]?.trim() || 'أسود',
        hex: parts[1]?.trim() || '#111'
      };
    });

    const finalImage = customImageUrl.trim() || selectedImage;

    const discountPercentage = originalPrice > price
      ? Math.round(((originalPrice - price) / originalPrice) * 100)
      : undefined;

    if (editingProduct) {
      const updated: Product = {
        ...editingProduct,
        name,
        nameEn: nameEn || name,
        price,
        originalPrice: originalPrice > price ? originalPrice : undefined,
        discountPercentage,
        category,
        gender,
        description,
        fabric,
        fit,
        images: [finalImage, ...editingProduct.images.slice(1)],
        sizes: parsedSizes.length > 0 ? parsedSizes : ['M', 'L', 'XL'],
        colors: parsedColors.length > 0 ? parsedColors : [{ name: 'أسود', hex: '#111' }]
      };
      onUpdateProduct(updated);
    } else {
      const newProduct: Product = {
        id: `ae-${Date.now()}`,
        name,
        nameEn: nameEn || 'Custom Luxury Piece',
        price,
        originalPrice: originalPrice > price ? originalPrice : undefined,
        discountPercentage,
        category,
        gender,
        description: description || 'قطعة أزياء فاخرة من كولكشن Ahmed Elgohary تم تصميمها بأعلى دقة وخامات ممتازة.',
        fabric,
        fit,
        care: 'غسيل آلي بماء بارد',
        images: [finalImage],
        sizes: parsedSizes.length > 0 ? parsedSizes : ['M', 'L', 'XL'],
        colors: parsedColors.length > 0 ? parsedColors : [{ name: 'أسود', hex: '#111' }],
        isNew: true,
        rating: 5.0,
        reviewsCount: 1,
        stockCount: 15
      };
      onAddProduct(newProduct);
    }

    handleResetForm();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-[#111115] border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto text-right">
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X size={20} />
          </button>
          <div className="flex items-center gap-3">
            <span className="text-sm font-semibold text-amber-400 font-display">لوحة التحكم</span>
            <span className="text-white font-bold text-base">| إدارة كتالوج ملابس Ahmed Elgohary</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-950 px-6">
          <button
            onClick={() => {
              setEditingProduct(null);
              setActiveTab('list');
            }}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'list'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            قائمة المنتجات الحالية ({products.length})
          </button>
          <button
            onClick={() => setActiveTab('add')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'add'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-white'
            }`}
          >
            {editingProduct ? `تعديل المنتج: ${editingProduct.name}` : '+ إضافة منتج جديد'}
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {activeTab === 'list' ? (
            <div className="space-y-3">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs text-neutral-400">يمكنك تعديل الأسعار، الصور، والبيانات أو حذف أي منتج فوراً:</span>
                <button
                  onClick={() => {
                    handleResetForm();
                    setActiveTab('add');
                  }}
                  className="px-3.5 py-1.5 bg-amber-400 text-black text-xs font-bold rounded-lg hover:bg-amber-300 flex items-center gap-1.5"
                >
                  <Plus size={14} />
                  <span>إضافة منتج جديد</span>
                </button>
              </div>

              <div className="grid grid-cols-1 gap-2">
                {products.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-3 bg-neutral-900 border border-neutral-800 rounded-xl hover:border-neutral-700 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-14 rounded-lg bg-neutral-800 overflow-hidden shrink-0">
                        <img
                          src={p.images[0]}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="font-bold text-white text-xs sm:text-sm">{p.name}</div>
                        <div className="flex items-center gap-2 text-[11px] text-neutral-400 mt-0.5">
                          <span className="text-amber-400 font-mono font-bold">{p.price} ج.م</span>
                          {p.originalPrice && <span className="line-through">{p.originalPrice} ج.م</span>}
                          <span>·</span>
                          <span>المقاسات: {p.sizes.join(', ')}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleStartEdit(p)}
                        className="p-2 text-neutral-300 hover:text-amber-400 hover:bg-neutral-800 rounded-lg transition-colors"
                        title="تعديل المنتج"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`هل أنت متأكد من حذف المنتج: ${p.name}؟`)) {
                            onDeleteProduct(p.id);
                          }
                        }}
                        className="p-2 text-neutral-500 hover:text-red-400 hover:bg-neutral-800 rounded-lg transition-colors"
                        title="حذف المنتج"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Add/Edit Product Form */
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">اسم المنتج (باللغة العربية) *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: هودي أوفرسايز فخم أسود كربوني"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">الاسم بالإنجليزية</label>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    placeholder="Signature Oversized Hoodie"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">السعر الحالي (ج.م) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">السعر قبل الخصم (اختياري)</label>
                  <input
                    type="number"
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(Number(e.target.value))}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">الفئة التصنيفية</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ProductCategory)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="hoodies">هوديز وسويت شيرت</option>
                    <option value="jackets">جواكت ومعاطف</option>
                    <option value="tshirts">تيشيرتات</option>
                    <option value="pants">بناطيل وكارجو</option>
                    <option value="sets">أطقم وبدلات</option>
                  </select>
                </div>
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">الجمهور المستهدف</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as TargetGender)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="men">رجالي</option>
                    <option value="women">حريمي</option>
                    <option value="unisex">يونيسكس (للجنسين)</option>
                  </select>
                </div>
              </div>

              {/* Sizes and Colors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">المقاسات المتاحة (مفصولة بفاصلة)</label>
                  <input
                    type="text"
                    value={sizesInput}
                    onChange={(e) => setSizesInput(e.target.value)}
                    placeholder="S, M, L, XL, XXL"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">الألوان (الصيغة: اسم:كود_هيكس)</label>
                  <input
                    type="text"
                    value={colorsInput}
                    onChange={(e) => setColorsInput(e.target.value)}
                    placeholder="أسود:#111, كحلي:#161b26, رمادي:#4a4d52"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Image Selection */}
              <div>
                <label className="block text-neutral-300 mb-2 font-semibold flex items-center gap-1.5">
                  <ImageIcon size={15} className="text-amber-400" />
                  <span>اختر صورة المنتج من الاستوديو أو أدخل رابط صورة مخصص:</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-3">
                  {presetImages.map((img, i) => (
                    <div
                      key={i}
                      onClick={() => {
                        setSelectedImage(img.url);
                        setCustomImageUrl('');
                      }}
                      className={`cursor-pointer rounded-lg overflow-hidden border-2 p-1 bg-neutral-900 text-center transition-all ${
                        selectedImage === img.url && !customImageUrl
                          ? 'border-amber-400 ring-2 ring-amber-400/30'
                          : 'border-neutral-800 hover:border-neutral-600'
                      }`}
                    >
                      <div className="aspect-square rounded overflow-hidden mb-1">
                        <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                      </div>
                      <span className="text-[10px] text-neutral-300 font-medium">{img.label}</span>
                    </div>
                  ))}
                </div>
                <input
                  type="url"
                  value={customImageUrl}
                  onChange={(e) => setCustomImageUrl(e.target.value)}
                  placeholder="أو ضع رابط صورة خارجي مباشر هنا (اختياري)..."
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400 text-left dir-ltr"
                />
              </div>

              {/* Description & Fabric */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">تفاصيل الخامة والقماش</label>
                  <input
                    type="text"
                    value={fabric}
                    onChange={(e) => setFabric(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-neutral-300 mb-1 font-semibold">ستايل القصة</label>
                  <input
                    type="text"
                    value={fit}
                    onChange={(e) => setFit(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-neutral-300 mb-1 font-semibold">وصف المنتج</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="اكتب وصفاً جذاباً يوضح تفاصيل القطعة وأناقتها..."
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2.5 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-neutral-800">
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-4 py-2.5 bg-neutral-800 text-neutral-300 rounded-lg hover:bg-neutral-700"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold rounded-lg flex items-center gap-2 shadow-lg shadow-amber-500/10 cursor-pointer"
                >
                  <CheckCircle2 size={16} />
                  <span>{editingProduct ? 'حفظ التعديلات' : 'إضافة المنتج إلى المتجر'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
