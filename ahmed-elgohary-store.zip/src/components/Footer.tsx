import React from 'react';
import { Phone, Mail, MapPin, Instagram, Facebook, ArrowUp } from 'lucide-react';
import { ProductCategory } from '../types';

interface FooterProps {
  onSelectCategory: (cat: ProductCategory) => void;
  onNavigateSection: (sec: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onNavigateSection }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#08080a] border-t border-neutral-800 text-right text-xs text-neutral-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Info (2 cols on lg) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black text-sm">
                AE
              </div>
              <span className="text-xl font-black text-white tracking-tight uppercase font-display">
                Ahmed Elgohary
              </span>
            </div>

            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              العلامة الرائدة في تصميم وتصنيع الأزياء والملابس الشبابية الفاخرة في مصر. أقمشة قطنية نقية 100%، وقصات عصرية مصممة لتمنحك الراحة والثقة الكاملة.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-300 hover:text-amber-400 hover:border-amber-400/40 transition-colors"
              >
                <Instagram size={15} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="w-8 h-8 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-300 hover:text-amber-400 hover:border-amber-400/40 transition-colors"
              >
                <Facebook size={15} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">أقسام المتجر</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => {
                    onSelectCategory('all');
                    onNavigateSection('products');
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  جميع المنتجات
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectCategory('men');
                    onNavigateSection('products');
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  كولكشن رجالي
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectCategory('women');
                    onNavigateSection('products');
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  كولكشن حريمي
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectCategory('hoodies');
                    onNavigateSection('products');
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  الهوديز والسويت شيرت
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectCategory('jackets');
                    onNavigateSection('products');
                  }}
                  className="hover:text-amber-400 transition-colors"
                >
                  الجواكت والمعاطف
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    onSelectCategory('offers');
                    onNavigateSection('products');
                  }}
                  className="text-amber-400 hover:underline font-semibold"
                >
                  العروض والخصومات
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Service & Help */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">خدمة العملاء</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigateSection('about')}
                  className="hover:text-white transition-colors"
                >
                  من نحن وقصة البراند
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('reviews')}
                  className="hover:text-white transition-colors"
                >
                  آراء وتجارب العملاء
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('contact')}
                  className="hover:text-white transition-colors"
                >
                  تواصل معنا
                </button>
              </li>
              <li>
                <span className="text-neutral-500">سياسة الاستبدال (14 يوم)</span>
              </li>
              <li>
                <span className="text-neutral-500">الشحن والتسليم</span>
              </li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">بيانات التواصل</h4>
            <div className="space-y-2.5">
              <div className="flex items-center gap-2">
                <Phone size={14} className="text-amber-400 shrink-0" />
                <span className="font-mono text-neutral-300 dir-ltr">01020304050</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail size={14} className="text-amber-400 shrink-0" />
                <span className="text-neutral-300">contact@ahmedelgohary.com</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin size={14} className="text-amber-400 shrink-0 mt-0.5" />
                <span className="text-neutral-300">القاهرة الجديدة، التجمع الخامس، مصر</span>
              </div>
            </div>

            {/* Back to top button & Download Project */}
            <div className="pt-2 flex flex-col gap-2">
              <a
                href="/ahmed-elgohary-store.zip"
                download="ahmed-elgohary-store.zip"
                className="inline-flex items-center justify-center gap-1.5 text-xs text-amber-300 hover:text-white bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <span>تحميل كود المشروع لـ GitHub (ZIP)</span>
              </a>
              <button
                onClick={scrollToTop}
                className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 px-3 py-1.5 rounded-lg transition-colors"
              >
                <ArrowUp size={13} />
                <span>العودة للأعلى</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom copyright & payment bar */}
        <div className="mt-12 pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            جميع الحقوق محفوظة © {new Date().getFullYear()} لعلامة <span className="text-neutral-300 font-semibold">Ahmed Elgohary</span> للأزياء والملابس الفاخرة.
          </div>
          <div className="flex items-center gap-3">
            <span>طرق الدفع المدعومة: الدفع عند الاستلام · فودافون كاش · إنستاباي · فيزا وميزة</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
