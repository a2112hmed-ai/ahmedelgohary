import React, { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [msg, setMsg] = useState('مرحباً، أود الاستفسار عن كولكشن الملابس المتاح في متجر Ahmed Elgohary');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    window.open(`https://wa.me/201020304050?text=${encodeURIComponent(msg)}`, '_blank');
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 text-right">
      {/* Popover Bubble */}
      {isOpen && (
        <div className="mb-3 w-80 bg-[#121217] border border-emerald-500/30 rounded-2xl shadow-2xl p-4 text-xs space-y-3 animate-fade-in">
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <button
              onClick={() => setIsOpen(false)}
              className="text-neutral-400 hover:text-white p-1"
            >
              <X size={15} />
            </button>
            <div className="flex items-center gap-2">
              <div>
                <div className="font-bold text-white text-xs">خدمة عملاء Ahmed Elgohary</div>
                <div className="text-[10px] text-emerald-400 flex items-center gap-1 justify-end">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>متصل الآن للرد عليك</span>
                </div>
              </div>
              <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                AE
              </div>
            </div>
          </div>

          <div className="bg-neutral-900 rounded-lg p-2.5 text-neutral-300 text-[11px] leading-relaxed border border-neutral-800">
            أهلاً بك في متجر Ahmed Elgohary! كيف نقدر نساعدك النهاردة؟ اسألنا عن أي مقاس أو استفسار بخصوص الشحن وهنرد عليك فوراً.
          </div>

          <form onSubmit={handleSend} className="space-y-2">
            <textarea
              rows={2}
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-2 text-white text-[11px] focus:outline-none focus:border-emerald-400"
            />
            <button
              type="submit"
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 text-xs transition-colors cursor-pointer"
            >
              <Send size={13} />
              <span>بدء المحادثة على الواتساب</span>
            </button>
          </form>
        </div>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="تواصل عبر واتساب"
        className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white shadow-xl shadow-emerald-900/40 flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95 group cursor-pointer relative"
      >
        <MessageCircle size={28} className="group-hover:rotate-6 transition-transform" />
        <span className="absolute -top-1 -left-1 w-3.5 h-3.5 bg-amber-400 rounded-full border-2 border-[#0c0c0e]"></span>
      </button>
    </div>
  );
};
