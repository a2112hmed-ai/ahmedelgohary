import React, { useState } from 'react';
import { X, ShoppingBag, Heart, Star, Check, ShieldCheck, Truck, RefreshCw, MessageCircle, Ruler } from 'lucide-react';
import { Product, ProductColor } from '../types';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, color: ProductColor, quantity: number) => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
  relatedProducts: Product[];
  onSelectRelatedProduct: (product: Product) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onAddToCart,
  isWishlisted,
  onToggleWishlist,
  relatedProducts,
  onSelectRelatedProduct
}) => {
  if (!product) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'L');
  const [selectedColor, setSelectedColor] = useState<ProductColor>(product.colors[0] || { name: 'أسود', hex: '#111' });
  const [quantity, setQuantity] = useState<number>(1);
  const [added, setAdded] = useState(false);
  const [showSizeGuide, setShowSizeGuide] = useState(false);

  const handleAdd = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleWhatsAppOrder = () => {
    const message = `مرحباً، أود الاستفسار وطلب منتج من Ahmed Elgohary:
- المنتج: ${product.name}
- المقاس: ${selectedSize}
- اللون: ${selectedColor.name}
- الكمية: ${quantity}
- السعر: ${(product.price * quantity).toLocaleString('ar-EG')} ج.م
رابط المنتج: ${window.location.origin}`;
    window.open(`https://wa.me/201020304050?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-[#111115] border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto text-right">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="إغلاق تفاصيل المنتج"
          className="absolute top-4 left-4 z-20 w-10 h-10 rounded-full bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-700 text-neutral-300 hover:text-white flex items-center justify-center transition-colors"
        >
          <X size={20} />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Gallery Column (Sticky left on desktop) */}
          <div className="p-4 sm:p-6 bg-neutral-950 flex flex-col justify-between border-b md:border-b-0 md:border-l border-neutral-800">
            {/* Main Featured Image */}
            <div className="relative aspect-[4/5] rounded-xl overflow-hidden bg-neutral-900 mb-4 border border-neutral-800">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
              {product.discountPercentage && (
                <div className="absolute top-3 right-3 bg-amber-500 text-black text-xs font-black px-2.5 py-1 rounded shadow">
                  خصم {product.discountPercentage}%
                </div>
              )}
            </div>

            {/* Thumbnail switcher if multiple images */}
            {product.images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-20 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                      activeImageIndex === idx
                        ? 'border-amber-400 scale-102'
                        : 'border-neutral-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} - ${idx + 1}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details & Purchase Module Column */}
          <div className="p-5 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                <div className="flex items-center gap-1.5 font-medium">
                  <span className="text-amber-400 font-semibold">Ahmed Elgohary</span>
                  <span aria-hidden="true">·</span>
                  <span>كولكشن 2025</span>
                </div>
                <div className="flex items-center gap-1 text-amber-400 font-semibold">
                  <Star size={14} className="fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                  <span className="text-neutral-500">({product.reviewsCount} تقييم)</span>
                </div>
              </div>

              {/* Product Name */}
              <h2 className="text-xl sm:text-2xl font-bold text-white mb-2 leading-tight">
                {product.name}
              </h2>
              <p className="text-xs text-neutral-500 mb-4 font-display">
                {product.nameEn}
              </p>

              {/* Price & Stock */}
              <div className="flex items-baseline justify-between mb-5 pb-4 border-b border-neutral-800">
                <div className="flex items-baseline gap-3">
                  <span className="text-2xl sm:text-3xl font-black text-amber-400 font-display tabular-nums">
                    {product.price.toLocaleString('ar-EG')} ج.م
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-neutral-500 line-through tabular-nums font-display">
                      {product.originalPrice.toLocaleString('ar-EG')} ج.م
                    </span>
                  )}
                </div>
                <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                  متوفر بالمخزن ({product.stockCount} قطع)
                </span>
              </div>

              {/* Description */}
              <p className="text-sm text-neutral-300 leading-relaxed mb-5">
                {product.description}
              </p>

              {/* Color Selector */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-xs font-medium text-neutral-300 mb-2">
                  <span>اللون المختار:</span>
                  <span className="text-amber-400 font-bold">{selectedColor.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  {product.colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                        selectedColor.name === c.name
                          ? 'border-amber-400 bg-neutral-850 text-white'
                          : 'border-neutral-800 bg-neutral-900/50 text-neutral-400 hover:text-white'
                      }`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full inline-block border border-white/20"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span>{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selector + Size Guide */}
              <div className="mb-5">
                <div className="flex items-center justify-between text-xs font-medium text-neutral-300 mb-2">
                  <span>المقاس المتاح:</span>
                  <button
                    onClick={() => setShowSizeGuide(!showSizeGuide)}
                    className="text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <Ruler size={13} />
                    <span>دليل المقاسات</span>
                  </button>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {product.sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`py-2 text-xs font-bold rounded-lg transition-all ${
                        selectedSize === sz
                          ? 'bg-amber-400 text-black shadow-md shadow-amber-500/20'
                          : 'bg-neutral-850 border border-neutral-700/80 text-neutral-300 hover:text-white hover:border-neutral-600'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>

                {/* Size Guide Drawer */}
                {showSizeGuide && (
                  <div className="mt-3 p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-300">
                    <div className="font-semibold text-white mb-2">جدول المقاسات المقترح (بالسنتيمتر):</div>
                    <div className="grid grid-cols-4 gap-1 text-center font-mono text-[11px]">
                      <div className="text-neutral-500">المقاس</div>
                      <div className="text-neutral-500">محيط الصدر</div>
                      <div className="text-neutral-500">الطول</div>
                      <div className="text-neutral-500">الوزن التقريبي</div>

                      <div className="font-bold">M</div><div>110 سم</div><div>72 سم</div><div>60-72 كجم</div>
                      <div className="font-bold">L</div><div>116 سم</div><div>74 سم</div><div>73-84 كجم</div>
                      <div className="font-bold">XL</div><div>122 سم</div><div>76 سم</div><div>85-95 كجم</div>
                      <div className="font-bold">XXL</div><div>128 سم</div><div>78 سم</div><div>96-110 كجم</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Quantity Stepper & Add to Cart Module */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded-lg p-1">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 flex items-center justify-center font-bold"
                  >
                    -
                  </button>
                  <span className="w-10 text-center font-display font-bold text-white text-sm tabular-nums">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stockCount, quantity + 1))}
                    className="w-8 h-8 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 flex items-center justify-center font-bold"
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart button */}
                <button
                  onClick={handleAdd}
                  className={`flex-1 py-3 px-4 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                    added
                      ? 'bg-emerald-600 text-white'
                      : 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black shadow-lg shadow-amber-500/20'
                  }`}
                >
                  {added ? (
                    <>
                      <Check size={18} />
                      <span>تمت الإضافة بنجاح</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag size={18} />
                      <span>أضف إلى السلة ({(product.price * quantity).toLocaleString('ar-EG')} ج.م)</span>
                    </>
                  )}
                </button>

                {/* Wishlist toggle */}
                <button
                  onClick={() => onToggleWishlist(product.id)}
                  aria-label="المفضلة"
                  className="w-12 h-12 rounded-lg bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-red-400 transition-colors"
                >
                  <Heart
                    size={20}
                    className={isWishlisted ? 'fill-red-500 text-red-500' : ''}
                  />
                </button>
              </div>

              {/* Direct WhatsApp Ordering */}
              <button
                onClick={handleWhatsAppOrder}
                className="w-full py-2.5 px-4 rounded-lg border border-emerald-500/40 bg-emerald-950/20 hover:bg-emerald-950/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 transition-colors mb-6"
              >
                <MessageCircle size={16} className="text-emerald-400" />
                <span>اطلب هذا المنتج مباشرة عبر الواتساب</span>
              </button>

              {/* Fabric & Fit Details */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 space-y-2 text-xs text-neutral-300 mb-6">
                <div>
                  <span className="font-semibold text-neutral-200">الخامة: </span>
                  <span>{product.fabric}</span>
                </div>
                <div>
                  <span className="font-semibold text-neutral-200">القصة: </span>
                  <span>{product.fit}</span>
                </div>
                <div>
                  <span className="font-semibold text-neutral-200">إرشادات الغسيل: </span>
                  <span>{product.care}</span>
                </div>
              </div>

              {/* Trust markers */}
              <div className="grid grid-cols-3 gap-2 text-center text-[11px] text-neutral-400 pt-3 border-t border-neutral-800">
                <div className="flex flex-col items-center gap-1">
                  <ShieldCheck size={16} className="text-amber-400" />
                  <span>ضمان الجودة 100%</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <Truck size={16} className="text-amber-400" />
                  <span>توصيل سريع</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <RefreshCw size={16} className="text-amber-400" />
                  <span>استبدال 14 يوم</span>
                </div>
              </div>
            </div>

            {/* Related Products Section inside Modal */}
            {relatedProducts.length > 0 && (
              <div className="mt-8 pt-6 border-t border-neutral-800">
                <h4 className="text-xs font-bold text-neutral-400 mb-3">منتجات قد تعجبك أيضاً:</h4>
                <div className="grid grid-cols-3 gap-2">
                  {relatedProducts.slice(0, 3).map((item) => (
                    <button
                      key={item.id}
                      onClick={() => onSelectRelatedProduct(item)}
                      className="group/rel text-right bg-neutral-900/70 p-2 rounded-lg border border-neutral-800 hover:border-neutral-700 transition-all"
                    >
                      <div className="aspect-square rounded overflow-hidden bg-neutral-800 mb-1.5">
                        <img
                          src={item.images[0]}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover/rel:scale-105 transition-transform"
                        />
                      </div>
                      <div className="text-[11px] font-medium text-white truncate">{item.name}</div>
                      <div className="text-[10px] text-amber-400 font-bold tabular-nums">
                        {item.price.toLocaleString('ar-EG')} ج.م
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
