import React from 'react';
import { Filter, RotateCcw, ArrowUpDown, Check } from 'lucide-react';
import { ProductCategory } from '../types';

export type SortOption = 'featured' | 'bestsellers' | 'newest' | 'price-asc' | 'price-desc';

interface ProductsFilterProps {
  selectedCategory: ProductCategory;
  onSelectCategory: (cat: ProductCategory) => void;
  selectedSize: string;
  onSelectSize: (size: string) => void;
  selectedColor: string;
  onSelectColor: (color: string) => void;
  priceRange: 'all' | 'under1000' | '1000-1500' | 'above1500';
  onPriceRangeChange: (range: 'all' | 'under1000' | '1000-1500' | 'above1500') => void;
  sortBy: SortOption;
  onSortByChange: (sort: SortOption) => void;
  totalProductsCount: number;
  filteredProductsCount: number;
  onResetFilters: () => void;
}

export const ProductsFilter: React.FC<ProductsFilterProps> = ({
  selectedCategory,
  onSelectCategory,
  selectedSize,
  onSelectSize,
  selectedColor,
  onSelectColor,
  priceRange,
  onPriceRangeChange,
  sortBy,
  onSortByChange,
  totalProductsCount,
  filteredProductsCount,
  onResetFilters
}) => {
  const categories: Array<{ id: ProductCategory; label: string }> = [
    { id: 'all', label: 'جميع المنتجات' },
    { id: 'men', label: 'رجالي' },
    { id: 'women', label: 'حريمي' },
    { id: 'hoodies', label: 'هوديز وسويت شيرت' },
    { id: 'jackets', label: 'جواكت' },
    { id: 'tshirts', label: 'تيشيرتات' },
    { id: 'pants', label: 'بناطيل وكارجو' },
    { id: 'offers', label: 'العروض الخاصة' }
  ];

  const sizes = ['الكل', 'S', 'M', 'L', 'XL', 'XXL'];

  const colors = [
    { name: 'الكل', hex: '' },
    { name: 'أسود', hex: '#111113' },
    { name: 'أبيض', hex: '#ffffff' },
    { name: 'رمادي', hex: '#4a4d52' },
    { name: 'بيج', hex: '#d6c8b2' },
    { name: 'كحلي', hex: '#161b26' },
    { name: 'زيتي', hex: '#2e382d' }
  ];

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    selectedSize !== 'الكل' ||
    selectedColor !== 'الكل' ||
    priceRange !== 'all' ||
    sortBy !== 'featured';

  return (
    <div className="bg-[#111114] border border-neutral-800 rounded-xl p-4 sm:p-6 mb-8 text-right space-y-5">
      {/* Category Pills / Segmented Controls (Functional buttons as per frontend-design guidelines) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                isActive
                  ? 'bg-amber-400 text-black shadow-md shadow-amber-500/20 font-bold'
                  : 'bg-neutral-900 text-neutral-300 hover:text-white hover:bg-neutral-800 border border-neutral-800'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Advanced Filters Row: Size, Color, Price, Sort */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-3 border-t border-neutral-800/80">
        {/* Sizes Filter */}
        <div>
          <label className="block text-xs font-semibold text-neutral-400 mb-2">المقاس:</label>
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {sizes.map((s) => (
              <button
                key={s}
                onClick={() => onSelectSize(s)}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  selectedSize === s
                    ? 'bg-amber-400 text-black font-bold'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Colors Filter */}
        <div>
          <label className="block text-xs font-semibold text-neutral-400 mb-2">اللون:</label>
          <div className="flex items-center gap-1.5 flex-wrap">
            {colors.map((c) => (
              <button
                key={c.name}
                onClick={() => onSelectColor(c.name)}
                className={`px-2.5 py-1 text-xs rounded-md font-medium flex items-center gap-1.5 transition-colors ${
                  selectedColor === c.name
                    ? 'bg-amber-400 text-black font-bold'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                {c.hex && (
                  <span
                    className="w-2.5 h-2.5 rounded-full inline-block border border-white/20"
                    style={{ backgroundColor: c.hex }}
                  />
                )}
                <span>{c.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Price Range Filter */}
        <div>
          <label className="block text-xs font-semibold text-neutral-400 mb-2">نطاق السعر:</label>
          <select
            value={priceRange}
            onChange={(e) => onPriceRangeChange(e.target.value as any)}
            className="w-full bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
          >
            <option value="all">جميع الأسعار</option>
            <option value="under1000">أقل من 1000 ج.م</option>
            <option value="1000-1500">1000 - 1500 ج.م</option>
            <option value="above1500">أكثر من 1500 ج.م</option>
          </select>
        </div>

        {/* Sort By Filter */}
        <div>
          <label className="block text-xs font-semibold text-neutral-400 mb-2 flex items-center justify-between">
            <span>الترتيب حسب:</span>
            <ArrowUpDown size={12} className="text-amber-400" />
          </label>
          <select
            value={sortBy}
            onChange={(e) => onSortByChange(e.target.value as SortOption)}
            className="w-full bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-amber-400"
          >
            <option value="featured">المميز</option>
            <option value="bestsellers">الأكثر مبيعاً</option>
            <option value="newest">الأحدث وصولاً</option>
            <option value="price-asc">السعر: من الأقل للأعلى</option>
            <option value="price-desc">السعر: من الأعلى للأقل</option>
          </select>
        </div>
      </div>

      {/* Results status and reset */}
      <div className="flex items-center justify-between pt-3 border-t border-neutral-800/80 text-xs text-neutral-400">
        <div>
          عرض <span className="text-amber-400 font-bold tabular-nums">{filteredProductsCount}</span> من أصل{' '}
          <span className="text-white font-medium tabular-nums">{totalProductsCount}</span> منتج
        </div>

        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="text-neutral-400 hover:text-amber-400 flex items-center gap-1 transition-colors"
          >
            <RotateCcw size={13} />
            <span>إعادة ضبط الفلاتر</span>
          </button>
        )}
      </div>
    </div>
  );
};
