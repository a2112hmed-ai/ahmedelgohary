import React from 'react';
import { Sparkles, Compass, Award, Scissors } from 'lucide-react';
import { modelImg, setImg } from '../data/products';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-[#0c0c0e] border-t border-neutral-800 text-right">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Visual Showcase (Two asymmetric luxury editorial photos) */}
          <div className="relative grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="rounded-2xl overflow-hidden aspect-[3/4] bg-neutral-900 border border-neutral-800 shadow-xl">
                <img
                  src={modelImg}
                  alt="Ahmed Elgohary Brand Campaign"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="space-y-4 pt-8">
              <div className="rounded-2xl overflow-hidden aspect-[3/4] bg-neutral-900 border border-neutral-800 shadow-xl">
                <img
                  src={setImg}
                  alt="Ahmed Elgohary Tailored Details"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            {/* Subtle brand tag floating */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/90 backdrop-blur-md border border-amber-500/30 px-5 py-3 rounded-xl shadow-2xl text-center">
              <span className="text-amber-400 font-black text-xl font-display tracking-tight">AE</span>
              <div className="text-[11px] text-neutral-300 font-semibold mt-0.5">Ahmed Elgohary</div>
              <div className="text-[9px] text-neutral-500 uppercase tracking-widest font-mono">Originals</div>
            </div>
          </div>

          {/* Editorial Content */}
          <div className="space-y-6">
            <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
              قصة العلامة التجارية · فلسفة التصميم
            </div>

            <h2 className="text-3xl sm:text-4xl font-black text-white leading-tight font-display">
              رؤية جديدة للأزياء الشبابية بروح الفخامة والأصالة
            </h2>

            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
              انطلقت علامة <strong className="text-white">Ahmed Elgohary</strong> من شغف حقيقي بإعادة تعريف ستايل الشارع العربي والشبابي. نؤمن بأن الملابس ليست مجرد قطع ترتديها، بل هي تعبير مباشر عن هويتك وثقتك وطموحك.
            </p>

            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed">
              نختار أجود أنواع خيوط القطن المصري طويل التيلة، ونطور أقمشة الميلتون الثقيل والصوف البارد بأسلوب يجمع بين متانة الاستخدام اليومي والقصات المعمارية الدقيقة (Modern Minimalist Silhouette).
            </p>

            {/* Core Values Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
                  <Scissors size={20} />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white mb-1">تفصيل وقصات متقنة</h4>
                  <p className="text-[11px] text-neutral-400 leading-normal">
                    دراسة مريحة لكل مقاس لضمان توازن مثالي على الجسم دون ترهل أو ضيق.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-start gap-3">
                <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0">
                  <Award size={20} />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white mb-1">خامات استثنائية</h4>
                  <p className="text-[11px] text-neutral-400 leading-normal">
                    أقمشة قطنية منسوجة بوزن 280 حتى 420 جرام معالجة ضد الانكماش وتغيير اللون.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
