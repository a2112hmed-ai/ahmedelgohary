import React, { useState } from 'react';
import { ShoppingBag, Search, Menu, X, PlusCircle, Sparkles, Heart, Download } from 'lucide-react';
import { ProductCategory } from '../types';

interface NavbarProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenAdmin: () => void;
  onSearchChange: (query: string) => void;
  searchQuery: string;
  selectedCategory: ProductCategory;
  onSelectCategory: (cat: ProductCategory) => void;
  activeSection: string;
  onNavigateSection: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenAdmin,
  onSearchChange,
  searchQuery,
  selectedCategory,
  onSelectCategory,
  activeSection,
  onNavigateSection
}) => {
  const [showAnnouncement, setShowAnnouncement] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const navLinks = [
    { label: 'الرئيسية', section: 'hero' },
    { label: 'المنتجات', section: 'products', category: 'all' as ProductCategory },
    { label: 'رجالي', section: 'products', category: 'men' as ProductCategory },
    { label: 'حريمي', section: 'products', category: 'women' as ProductCategory },
    { label: 'العروض', section: 'offers' },
    { label: 'من نحن', section: 'about' },
    { label: 'تواصل معنا', section: 'contact' }
  ];

  const handleNavClick = (section: string, cat?: ProductCategory) => {
    if (cat) {
      onSelectCategory(cat);
    }
    onNavigateSection(section);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#0c0c0e]/90 border-b border-neutral-800/80 transition-all">
      {/* Top promotional bar */}
      {showAnnouncement && (
        <div className="bg-gradient-to-r from-neutral-900 via-neutral-850 to-neutral-900 border-b border-amber-500/20 px-4 py-1.5 text-xs text-neutral-300 flex items-center justify-between">
          <div className="flex-1 text-center font-medium flex items-center justify-center gap-2">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
            <span>شحن مجاني لكافة محافظات مصر عند الشراء بـ 1500 ج.م أو أكثر</span>
            <span className="hidden sm:inline text-neutral-500">|</span>
            <span className="hidden sm:inline text-amber-300/90 font-semibold">كولكشن الشتاء متاح الآن</span>
          </div>
          <button
            onClick={() => setShowAnnouncement(false)}
            aria-label="إغلاق التنبيه"
            className="text-neutral-400 hover:text-white transition-colors p-0.5"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Main Top Bar Contract: Zone 1 (Brand) — Zone 2 (Nav links) — Zone 3 (Actions) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Zone 1: Single element brand wordmark */}
        <button
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-2.5 text-right focus:outline-none group"
        >
          <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 flex items-center justify-center text-black font-black text-sm tracking-tighter shadow-md shadow-amber-500/10">
            AE
          </div>
          <span className="text-xl sm:text-2xl font-black tracking-tight text-white group-hover:text-amber-300 transition-colors uppercase font-display">
            Ahmed Elgohary
          </span>
        </button>

        {/* Zone 2: 4-6 Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-neutral-300">
          {navLinks.map((item) => {
            const isActive =
              item.category
                ? activeSection === 'products' && selectedCategory === item.category
                : activeSection === item.section;

            return (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.section, item.category)}
                className={`transition-colors relative py-1 text-sm ${
                  isActive
                    ? 'text-amber-400 font-semibold'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Search Toggle Button */}
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="p-2 text-neutral-300 hover:text-white hover:bg-neutral-800/80 rounded-full transition-colors"
            title="بحث عن منتج"
            aria-label="بحث"
          >
            <Search size={19} />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={onOpenWishlist}
            className="p-2 text-neutral-300 hover:text-white hover:bg-neutral-800/80 rounded-full transition-colors relative"
            title="المفضلة"
            aria-label="المفضلة"
          >
            <Heart size={19} />
            {wishlistCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-neutral-700 text-amber-300 border border-neutral-600 rounded-full text-[10px] font-bold flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Download Full Project for GitHub */}
          <a
            href="/ahmed-elgohary-store.zip"
            download="ahmed-elgohary-store.zip"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-black bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-md transition-all shadow-md shadow-amber-500/20 active:scale-95 cursor-pointer"
            title="تحميل كود المشروع بالكامل كملف ZIP لرفعه على GitHub"
          >
            <Download size={14} className="stroke-[2.5]" />
            <span className="hidden lg:inline">تحميل كود المشروع لـ GitHub</span>
            <span className="lg:hidden">تحميل الكود (ZIP)</span>
          </a>

          {/* Add / Manage Product Button (Admin mode) */}
          <button
            onClick={onOpenAdmin}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-amber-300 border border-neutral-700/80 hover:border-amber-500/40 rounded-md transition-colors"
            title="إدارة وإضافة المنتجات"
          >
            <PlusCircle size={14} className="text-amber-400" />
            <span>إضافة منتج</span>
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="flex items-center gap-2 bg-gradient-to-r from-neutral-850 to-neutral-800 hover:from-neutral-800 hover:to-neutral-750 text-white border border-amber-500/30 px-3.5 py-2 rounded-md transition-all shadow-sm group"
            aria-label="سلة المشتريات"
          >
            <div className="relative">
              <ShoppingBag size={18} className="text-amber-400 group-hover:scale-105 transition-transform" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2.5 min-w-[18px] h-[18px] bg-amber-500 text-black text-[11px] font-black rounded-full flex items-center justify-center px-1 tabular-nums animate-scale-in">
                  {cartCount}
                </span>
              )}
            </div>
            <span className="hidden sm:inline text-xs font-semibold text-neutral-200">
              السلة
            </span>
          </button>

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-neutral-300 hover:text-white rounded-md"
            aria-label="القائمة"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Search Bar expandable drawer */}
      {searchOpen && (
        <div className="border-t border-neutral-800 bg-[#101014] px-4 py-3 shadow-inner">
          <div className="max-w-2xl mx-auto relative flex items-center">
            <Search size={18} className="absolute right-3.5 text-neutral-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (e.target.value.trim() && activeSection !== 'products') {
                  onNavigateSection('products');
                }
              }}
              placeholder="ابحث بالاسم، هودي، جاكيت، بليزر، كارجو..."
              className="w-full bg-neutral-900 border border-neutral-700/80 rounded-lg pr-10 pl-10 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500/70 focus:ring-1 focus:ring-amber-500/50"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute left-3 text-neutral-400 hover:text-white"
              >
                <X size={16} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-neutral-800 bg-[#0e0e12] px-6 py-6 space-y-4">
          <div className="grid grid-cols-1 gap-1">
            {navLinks.map((item) => (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.section, item.category)}
                className="text-right py-3 px-3 rounded-lg text-base font-medium text-neutral-200 hover:text-amber-400 hover:bg-neutral-800/50 transition-colors flex items-center justify-between"
              >
                <span>{item.label}</span>
                {item.section === 'offers' && (
                  <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-bold">
                    خصومات
                  </span>
                )}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-neutral-800 flex flex-col gap-3">
            <a
              href="/ahmed-elgohary-store.zip"
              download="ahmed-elgohary-store.zip"
              className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-400 to-amber-500 text-black font-bold text-sm rounded-lg flex items-center justify-center gap-2 shadow-lg shadow-amber-500/10 cursor-pointer"
            >
              <Download size={16} />
              <span>تحميل كود المشروع لـ GitHub (ZIP)</span>
            </a>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="flex items-center gap-2 text-sm text-neutral-300 hover:text-amber-400"
              >
                <PlusCircle size={16} className="text-amber-400" />
                <span>إدارة وإضافة منتج</span>
              </button>
              <div className="text-xs text-neutral-500">
                خدمة العملاء: 01020304050
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
